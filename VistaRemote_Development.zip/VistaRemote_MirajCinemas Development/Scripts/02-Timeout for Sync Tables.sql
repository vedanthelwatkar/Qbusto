--column added for time out configuration.

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_intSyncTimeOut' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_intSyncTimeOut [int] NOT NULL CONSTRAINT DF_tblCinema_Cinema_intSyncTimeOut DEFAULT (180)
GO
