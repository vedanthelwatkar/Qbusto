﻿/* *************************************************************************************************

	Script Name   : Script for fnFormatString
	Last Modified : 8 Apr 2010 @ 5:00 PM
	Last Author   : Viraj Patel

************************************************************************************************* */

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[fnFormatString]')) BEGIN
	EXEC('CREATE FUNCTION [dbo].[fnFormatString] (@strStringToFormat As VarChar(4000), @strFormatOption As VarChar(1)) RETURNS VarChar(4000) AS BEGIN RETURN ISNULL(@strStringToFormat, '''') END')
END
GO
/* *************************************************************************************************

	Script Name   : Base Tables Creation Script for VISTACS
	Datebase      : VISTACS
	Last Modified : 11 Aug 2010 @ 11:30 PM
	Last Author   : Viraj Patel

************************************************************************************************* */

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[tblCinema]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN

	CREATE TABLE [dbo].[tblCinema] (
		[Cinema_strID] [varchar] (10) NOT NULL CONSTRAINT PK_tblCinema PRIMARY KEY CLUSTERED, 
		[Cinema_strName] [varchar] (50) NOT NULL , 
		[Cinema_dtmLastDataRefresh] [datetime] NULL ,
		[Cinema_strWebServiceURL] [varchar] (255) NOT NULL , 
		[Cinema_strWebServiceLogin] [varchar] (50) NOT NULL CONSTRAINT DF_tblCinema_Cinema_strWebServiceLogin DEFAULT ('') , 
		[Cinema_strWebServicePWD] [varchar] (50) NOT NULL CONSTRAINT DF_tblCinema_Cinema_strWebServicePWD DEFAULT ('') , 
		[Cinema_intTimeOut] [smallint] NOT NULL CONSTRAINT DF_tblCinema_Cinema_intTimeOut DEFAULT (0) ,
		[Cinema_strCatalogue1] [varchar] (50) NULL , 
		[Cinema_strCatalogue2] [varchar] (50) NULL , 
		[Cinema_strCatalogue3] [varchar] (50) NULL , 
		[Cinema_dtmStamp] [datetime] NOT NULL CONSTRAINT DF_tblCinema_Cinema_dtmStamp DEFAULT (GETDATE()) 
	) ON [PRIMARY]

END
GO

-- DELETE Columns

IF EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strSQLServer' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema DROP COLUMN Cinema_strSQLServer
GO

IF EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strSQLLogin' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema DROP COLUMN Cinema_strSQLLogin
GO

IF EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strSQLPassword' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema DROP COLUMN Cinema_strSQLPassword
GO

-- ADD Columns

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strLicenseName' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strLicenseName [varchar] (50) 
			CONSTRAINT DF_tblCinema_Cinema_strLicenseName DEFAULT ('') 
			NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strLicenseNo' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strLicenseNo [varchar] (20) 
			CONSTRAINT DF_tblCinema_Cinema_strLicenseNo DEFAULT ('') 
			NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strWebServiceDomain' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strWebServiceDomain [varchar] (50) 
			CONSTRAINT DF_tblCinema_Cinema_strWebServiceDomain DEFAULT ('') 
			NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strWebServiceLogin' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strWebServiceLogin [varchar] (50) 
			CONSTRAINT DF_tblCinema_Cinema_strWebServiceLogin DEFAULT ('') 
			NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strWebServicePWD' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strWebServicePWD [varchar] (50) 
			CONSTRAINT DF_tblCinema_Cinema_strWebServicePWD DEFAULT ('') 
			NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_intWebTimeOut' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_intWebTimeOut [int] 
			CONSTRAINT DF_tblCinema_Cinema_intWebTimeOut DEFAULT (10) 
			NOT NULL 
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strIsOnline' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strIsOnline [varchar] (1) 
			CONSTRAINT DF_tblCinema_Cinema_strIsOnline DEFAULT ('Y') 
			NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_intSyncSequence' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_intSyncSequence [smallint] 
			CONSTRAINT DF_tblCinema_Cinema_intSyncSequence DEFAULT (1) 
			NOT NULL 
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strWebServiceVersion' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strWebServiceVersion [varchar] (20)
			CONSTRAINT DF_tblCinema_Cinema_strWebServiceVersion DEFAULT ('') 
			NOT NULL 
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strVistaRemoteVersion' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strVistaRemoteVersion [varchar] (50)
			CONSTRAINT DF_tblCinema_Cinema_strVistaRemoteVersion DEFAULT ('Bigtree.VistaRemote.dll') 
			NOT NULL 
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strCompanyCode' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strCompanyCode [varchar] (10)
			CONSTRAINT DF_tblCinema_Cinema_strCompanyCode DEFAULT ('') 
			NOT NULL 
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strRegion' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strRegion [varchar] (30)
			CONSTRAINT DF_tblCinema_Cinema_strRegion DEFAULT ('') 
			NOT NULL 
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strBranchCode' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strBranchCode [varchar] (4) 
			CONSTRAINT DF_tblCinema_Cinema_strBranchCode DEFAULT ('') 
			NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strScreenList' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strScreenList [varchar] (1000) 
			CONSTRAINT DF_tblCinema_Cinema_strScreenList DEFAULT ('') 
			NOT NULL  
GO

IF EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strScreenList' AND id = OBJECT_ID(N'[dbo].[tblCinema]') AND length < 1000) 
	ALTER TABLE tblCinema 
		ALTER COLUMN Cinema_strScreenList [varchar] (1000) NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strParams' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strParams [varchar] (255) 
			CONSTRAINT DF_tblCinema_Cinema_strParams DEFAULT ('') 
			NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strUseHOCode' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strUseHOCode [varchar] (1) 
			CONSTRAINT DF_tblCinema_Cinema_strUseHOCode DEFAULT ('N') 
			NOT NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strWebServiceURL2' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strWebServiceURL2 [varchar] (255) NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_strWebServiceURL3' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_strWebServiceURL3 [varchar] (255) NULL  
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Cinema_intSyncTimeOut' AND id = OBJECT_ID(N'[dbo].[tblCinema]')) 
	ALTER TABLE tblCinema 
		ADD Cinema_intSyncTimeOut [int] NOT NULL CONSTRAINT DF_tblCinema_Cinema_intSyncTimeOut DEFAULT (180)
GO

-- Create Table

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[tblLicenses]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN

	CREATE TABLE [dbo].[tblLicenses] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[License_strType] [varchar] (10) NOT NULL , 
		[License_strCode] [varchar] (50) NOT NULL , 
		[License_strPayType] [varchar] (50) NOT NULL , 
		[License_dtmStamp] [datetime] DEFAULT (GETDATE()) NOT NULL , 
		CONSTRAINT [PK_tblLicenses] PRIMARY KEY CLUSTERED 
		(
			[Cinema_strID],
			[License_strType]
		) ,
		CONSTRAINT [FK_tblLicenses_tblCinema] FOREIGN KEY 
		(
			[Cinema_strID]
		) REFERENCES [dbo].[tblCinema] (
			[Cinema_strID]
		)
	) ON [PRIMARY]

END
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'License_strUserNo' AND id IN (SELECT id FROM sysobjects WHERE name = 'tblLicenses')) 
	ALTER TABLE tblLicenses 
		ADD License_strUserNo [varchar] (10)
			CONSTRAINT DF_tblLicenses_License_strUserNo DEFAULT ('') 
			NOT NULL 
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'License_strWorkstationId' AND id IN (SELECT id FROM sysobjects WHERE name = 'tblLicenses')) 
	ALTER TABLE tblLicenses 
		ADD License_strWorkstationId [varchar] (50)
			CONSTRAINT DF_tblLicenses_License_strWorkstationId DEFAULT ('') 
			NOT NULL 
GO

-- Update the tblCinema to set the WebTimeOut of a WebService to atleast 45 secs.

UPDATE tblCinema SET Cinema_intWebTimeOut = 45 WHERE Cinema_intWebTimeOut < 45
GO

-- Create Table

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'tblCinema_Settings' AND OBJECTPROPERTY(OBJECT_ID(name), 'IsTable') = 1) BEGIN

	CREATE TABLE [dbo].[tblCinema_Settings] (
		Cinema_strID VarChar(10) NOT NULL, 
		Cinema_strParamName VarChar(50) NOT NULL,
		Cinema_strParamValue VarChar(1000) NOT NULL,
		Cinema_dtmParamStamp DateTime NOT NULL CONSTRAINT [DF_tblCinema_Settings_Cinema_dtmParamStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_tblCinema_Settings] PRIMARY KEY
		(
			[Cinema_strID], 
			[Cinema_strParamName] 
		), 
		CONSTRAINT [FK_tblCinema_Settings_tblCinema] FOREIGN KEY 
		(
			[Cinema_strID]
		)
		REFERENCES [dbo].[tblCinema]
		(
			[Cinema_strID]
		)
	) ON [PRIMARY]

END
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'tblCinema_SyncSettings' AND OBJECTPROPERTY(OBJECT_ID(name), 'IsTable') = 1) BEGIN

	CREATE TABLE [dbo].[tblCinema_SyncSettings] (
		Cinema_strID VarChar(10) NOT NULL, 
		Cinema_strParamName VarChar(50) NOT NULL,
		Cinema_strParamValue VarChar(1000) NOT NULL,
		Cinema_dtmParamStamp DateTime NOT NULL CONSTRAINT [DF_tblCinema_SyncSettings_Cinema_dtmParamStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_tblCinema_SyncSettings] PRIMARY KEY
		(
			[Cinema_strID], 
			[Cinema_strParamName] 
		), 
		CONSTRAINT [FK_tblCinema_SyncSettings_tblCinema] FOREIGN KEY 
		(
			[Cinema_strID]
		)
		REFERENCES [dbo].[tblCinema]
		(
			[Cinema_strID]
		)
	) ON [PRIMARY]

END
GO

/* *************************************************************************************************

	Script Name   : SyncTables Creation Script for VISTACS
	Datebase      : VISTACS
	Last Modified : 14 Nov 2011 @ 10:00 PM
	Last Author   : Viraj Patel

************************************************************************************************* */

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblSession_Attribute_tblSession]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblSession_Attribute] DROP CONSTRAINT FK_SYN_tblSession_Attribute_tblSession
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblSession_SYN_tblFilm]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblSession] DROP CONSTRAINT FK_SYN_tblSession_SYN_tblFilm
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblPrices_Packages_SYN_tblPrices]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblPrices_Packages] DROP CONSTRAINT FK_SYN_tblPrices_Packages_SYN_tblPrices
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblSession_AreaCount_SYN_tblSession]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblSession_AreaCount] DROP CONSTRAINT FK_SYN_tblSession_AreaCount_SYN_tblSession
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblBookingFee_tblCinema]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblBookingFee] DROP CONSTRAINT FK_SYN_tblBookingFee_tblCinema
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblItems_tblCinema]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblItems] DROP CONSTRAINT FK_SYN_tblItems_tblCinema
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblPrices_tblCinema]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblPrices] DROP CONSTRAINT FK_SYN_tblPrices_tblCinema
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblSession_tblCinema]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblSession] DROP CONSTRAINT FK_SYN_tblSession_tblCinema
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblPerson_tblCinema]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblPerson] DROP CONSTRAINT FK_SYN_tblPerson_tblCinema
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[FK_SYN_tblPerson_SYN_tblFilm]') AND OBJECTPROPERTY(id, N'IsForeignKey') = 1)
--	ALTER TABLE [dbo].[SYN_tblPerson] DROP CONSTRAINT FK_SYN_tblPerson_SYN_tblFilm
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblBookingFee]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblBookingFee]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblSession_AreaCount]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblSession_AreaCount]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblSession_Attribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblSession_Attribute]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblSession]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblSession]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblPerson]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblPerson]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblFilm_Attribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblFilm_Attribute]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblFilm]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblFilm]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblItem_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblItem_Packages]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblItems]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblItems]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblPrices_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblPrices_Packages]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblPrices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblPrices]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblItem_Prices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[SYN_tblItem_Prices]
--GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblBookingFee]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblBookingFee] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[BFee_strCode] [varchar] (10) NOT NULL , 
		[License_strType] [varchar] (10) NOT NULL , 
		[TType_strCode] [varchar] (10) NOT NULL , 
		[BFee_curFeeMinimum] [money] NULL ,
		[BFee_curFeeMaximum] [money] NULL ,
		[BFee_curFee] [money] NULL ,
		[BFee_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblBookingFee_BFee_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblBookingFee] PRIMARY KEY  CLUSTERED 
		(
			[Cinema_strID],
			[BFee_strCode],
			[License_strType],
			[TType_strCode]
		), 
		CONSTRAINT [FK_SYN_tblBookingFee_tblCinema] FOREIGN KEY 
		(
			[Cinema_strID]
		) REFERENCES [dbo].[tblCinema] (
			[Cinema_strID]
		)
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblFilm]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblFilm] (
		[Film_strCode] [varchar] (20) NOT NULL CONSTRAINT [PK_SYN_tblFilm] PRIMARY KEY , 
		[Film_strTitle] [varchar] (500) NULL , 
		[Film_strCensor] [varchar] (10) NULL , 
		[Film_strContent] [nvarchar] (255) NULL , 
		[Film_strDescription] [varchar] (255) NULL , 
		[Film_strShortName] [varchar] (10) NULL , 
		[Film_strSignText] [varchar] (20) NULL , 
		[Film_bytSignSequence] [tinyint] NULL ,
		[FilmCat_strCode] [varchar] (10) NULL , 
		[FilmCat_strName] [varchar] (30) NULL , 
		[FilmCat_strShortName] [varchar] (10) NULL , 
		[Film_strChildren] [varchar] (1) NULL , 
		[Film_intDuration] [smallint] NULL ,
		[Film_strStatus] [varchar] (1) NULL , 
		[Film_strATMAvailable] [char] (1) NULL , 
		[Film_strShortCode] [nvarchar] (15) NULL , 
		[Film_intIVRCode] [int] NULL ,
		[Film_strURL1] [varchar] (255) NULL , 
		[Film_strURL2] [varchar] (255) NULL , 
		[Film_strVCode] [varchar] (5) NULL , 
		[Film_strTitleAlt] [nvarchar] (50) NULL , 
		[Film_strCensorAlt] [nvarchar] (4) NULL , 
		[Film_strContentAlt] [nvarchar] (255) NULL , 
		[Film_strDescriptionAlt] [nvarchar] (255) NULL , 
		[Film_strShortNameAlt] [nvarchar] (10) NULL , 
		[Film_strSignTextAlt] [nvarchar] (20) NULL , 
		[Film_strURL1Description] [nvarchar] (100) NULL , 
		[Film_strURL2Description] [nvarchar] (100) NULL , 
		[Film_strURLforGraphic] [varchar] (255) NULL , 
		[Film_strURLforFilmName] [varchar] (255) NULL , 
		[Film_strURLforTrailer] [varchar] (255) NULL , 
		[Film_strMovieFormat] [nvarchar] (30) NULL , 
		[Film_strSoundFormat] [nvarchar] (30) NULL , 
		[Film_mnyGross] [money] NULL ,
		[Film_mnyLocalGross] [money] NULL ,
		[Film_strUpcomingFlag] [varchar] (1) NULL , 
		[Film_strFeatureFlag] [varchar] (1) NULL , 
		[Film_strNowShowingFlag] [varchar] (1) NULL , 
		[Film_dtmOpeningDate] [datetime] NULL ,
		[Film_strDescriptionLong] [ntext] NULL , 
		[Film_strAdditionalData] [VarChar] (1000) NULL ,
		[Film_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblFilm_Film_dtmStamp] DEFAULT GETDATE()
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblFilm]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Film_strSalesChannels' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblFilm'))
		ALTER TABLE SYN_tblFilm 
			ADD Film_strSalesChannels [varchar] (500) NULL
	END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblFilm_Attribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblFilm_Attribute] (
		[Film_strCode] [varchar] (20) NOT NULL , 
		[Attrib_strCode] [varchar] (10) NOT NULL , 
		[Attrib_strClass] [varchar] (30) NOT NULL , 
		[Attrib_strDescription] [nvarchar] (100) NOT NULL , 
		[Attrib_strShortName] [nvarchar] (20) NULL , 
		[Attrib_strAltDescription] [nvarchar] (100) NULL , 
		[Attrib_strAltShortName] [nvarchar] (20) NULL , 
		[Attrib_strIconName] [nvarchar] (60) NULL , 
		[Attrib_strHOCode] [varchar] (10) NULL , 
		[Attrib_strStatus] [char] (1) NOT NULL , 
		[Attrib_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblFilm_Attribute_Attrib_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblFilm_Attribute] PRIMARY KEY CLUSTERED ([Film_strCode], [Attrib_strCode])
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblItems]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblItems] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Item_strID] [varchar] (15) NOT NULL , 
		[Item_strDescription] [varchar] (255) NULL , 
		[Item_intPrice] [int] NOT NULL ,
		[Item_strVoiceFileName] [varchar] (12) NULL , 
		[Item_strMasterItemCode] [varchar] (15) NULL , 
		[Item_strAdditionalData] [varchar] (1000) NULL , 
		[Class_strCode1] [varchar] (4) NULL , 
		[Class_strDesc1] [varchar] (50) NULL , 
		[Class_strCode2] [varchar] (4) NULL , 
		[Class_strDesc2] [varchar] (50) NULL , 
		[Class_strCode3] [varchar] (4) NULL , 
		[Class_strDesc3] [varchar] (50) NULL , 
		[Item_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblItems_Item_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblItems] PRIMARY KEY  CLUSTERED 
		(
			[Cinema_strID],
			[Item_strID]
		) , 
		CONSTRAINT [FK_SYN_tblItems_tblCinema] FOREIGN KEY 
		(
			[Cinema_strID]
		) REFERENCES [dbo].[tblCinema] (
			[Cinema_strID]
		)
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblItems]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Class_strCode1' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Class_strCode1 [varchar] (4) NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Class_strDesc1' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Class_strDesc1 [varchar] (50) NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Class_strCode2' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Class_strCode2 [varchar] (4) NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Class_strDesc2' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Class_strDesc2 [varchar] (50) NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Class_strCode3' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Class_strCode3 [varchar] (4) NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Class_strDesc3' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Class_strDesc3 [varchar] (50) NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax1' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Item_intTax1 [int] NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax2' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Item_intTax2 [int] NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax3' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Item_intTax3 [int] NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax4' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Item_intTax4 [int] NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_strPackage' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD Item_strPackage [varchar] (1) NULL
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'CinOperator_strCode' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItems'))
		ALTER TABLE SYN_tblItems 
			ADD CinOperator_strCode [varchar] (10) NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblPrices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblPrices] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[PGroup_strCode] [varchar] (4) NOT NULL , 
		[TType_strCode] [varchar] (4) NOT NULL , 
		[AreaCat_strCode] [varchar] (10) NOT NULL , 
		[BFee_strCode] [varchar] (10) NULL , 
		[TType_strDescription] [varchar] (25) NOT NULL , 
		[TType_strDescriptionAlt] [nvarchar] (25) NOT NULL , 
		[Price_intSequence] [smallint] NOT NULL ,
		[Price_curPrice] [money] NOT NULL ,
		[Price_strChildTicket] [varchar] (1) NOT NULL , 
		[Price_strPackage] [char] (1) NOT NULL , 
		[Price_strComp] [char] (1) NOT NULL , 
		[Price_dtmEffectFrom] [datetime] NULL ,
		[Price_dtmEffectTill] [datetime] NULL , 
		[Price_strQuantity] [varchar] (200) NULL , 
		[Price_strAdditionalData] [varchar] (1000) NULL , 
		[Price_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblPrices_Price_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblPrices] PRIMARY KEY CLUSTERED 
		(
			[Cinema_strID],
			[PGroup_strCode],
			[TType_strCode]
		), 
		CONSTRAINT [FK_SYN_tblPrices_tblCinema] FOREIGN KEY ([Cinema_strID]) REFERENCES [dbo].[tblCinema] ([Cinema_strID])
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblPrices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_strSalesChannels' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices'))
		ALTER TABLE SYN_tblPrices 
			ADD Price_strSalesChannels [VarChar] (500) NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax1' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices'))
		ALTER TABLE SYN_tblPrices 
			ADD Price_curTax1 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax2' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices'))
		ALTER TABLE SYN_tblPrices 
			ADD Price_curTax2 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax3' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices'))
		ALTER TABLE SYN_tblPrices 
			ADD Price_curTax3 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax4' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices'))
		ALTER TABLE SYN_tblPrices 
			ADD Price_curTax4 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'TType_strHOCode' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices'))
		ALTER TABLE SYN_tblPrices 
			ADD TType_strHOCode [varchar] (10) NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblPrices_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblPrices_Packages] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[PPack_strCode] [varchar] (10) NOT NULL , 
		[PGroup_strCode] [varchar] (4) NOT NULL , 
		[TType_strCode] [varchar] (4) NOT NULL , 
		[TType_strChildCode] [varchar] (4) NULL , 
		[Item_strItemId] [varchar] (15) NULL , 
		[PPack_curQuantity] [money] NULL ,
		[PPack_curPriceEach] [money] NULL ,
		[PPack_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblPrices_Packages_PPack_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblPrices_Packages] PRIMARY KEY  CLUSTERED 
		(
			[Cinema_strID],
			[PPack_strCode],
			[PGroup_strCode],
			[TType_strCode]
		) ,
		CONSTRAINT [FK_SYN_tblPrices_Packages_SYN_tblPrices] FOREIGN KEY 
		(
			[Cinema_strID],
			[PGroup_strCode],
			[TType_strCode]
		) REFERENCES [dbo].[SYN_tblPrices] (
			[Cinema_strID],
			[PGroup_strCode],
			[TType_strCode]
		)
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblPrices_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax1' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices_Packages'))
		ALTER TABLE SYN_tblPrices_Packages 
			ADD Price_curTax1 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax2' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices_Packages'))
		ALTER TABLE SYN_tblPrices_Packages 
			ADD Price_curTax2 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax3' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices_Packages'))
		ALTER TABLE SYN_tblPrices_Packages 
			ADD Price_curTax3 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax4' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblPrices_Packages'))
		ALTER TABLE SYN_tblPrices_Packages 
			ADD Price_curTax4 [money] NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblSession]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblSession] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Session_lngSessionId] [int] NOT NULL ,
		[Film_strCode] [varchar] (20) NULL , 
		[Screen_bytNum] [int] NULL , 
		[Layout_intId] [int] NULL , 
		[Screen_strName] [varchar] (25) NULL , 
		[Session_strStatus] [varchar] (1) NOT NULL , 
		[Session_strType] [varchar] (1) NULL , 
		[Session_dtmRealShow] [datetime] NOT NULL ,
		[Session_dtmFinishShow] [datetime] NOT NULL ,
		[PGroup_strCode] [varchar] (4) NOT NULL , 
		[Session_intSeatsAvail] [int] NOT NULL ,
		[Session_intSeatsTotal] [int] NULL , 
		[Session_strSeatAllocation] [varchar] (1) NOT NULL , 
		[Session_strComments] [nvarchar] (255) NOT NULL , 
		[Session_dtmFilmFirstShow] [datetime] NULL , 
		[Session_strHOSessionID] [varchar] (10) NULL , 
		[Event_strCode] [varchar] (10) NULL , 
		[Event_strName] [nvarchar] (100) NULL , 
		[Session_strAdditionalData] [varchar] (1000) NULL , 
		[Session_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblSession_Session_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblSession] PRIMARY KEY  CLUSTERED 
		(
			[Cinema_strID],
			[Session_lngSessionId]
		) ,
		CONSTRAINT [FK_SYN_tblSession_SYN_tblFilm] FOREIGN KEY 
		(
			[Film_strCode]
		) REFERENCES [dbo].[SYN_tblFilm] (
			[Film_strCode]
		) ,
		CONSTRAINT [FK_SYN_tblSession_tblCinema] FOREIGN KEY 
		(
			[Cinema_strID]
		) REFERENCES [dbo].[tblCinema] (
			[Cinema_strID]
		)
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblSession]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF EXISTS (SELECT * FROM syscolumns WHERE name = 'Session_strSalesChannels' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblSession'))
		ALTER TABLE SYN_tblSession 
			DROP COLUMN Session_strSalesChannels
			
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Session_strSalesChannel' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblSession'))
		ALTER TABLE SYN_tblSession 
			ADD Session_strSalesChannel [VarChar] (500) NULL
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'CinOperator_strCode' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblSession'))
		ALTER TABLE SYN_tblSession 
			ADD CinOperator_strCode [VarChar] (10) NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Session_strCinemaPopUpDesc' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblSession'))
		ALTER TABLE SYN_tblSession 
			ADD Session_strCinemaPopUpDesc [VarChar] (10) NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblSession_AreaCount]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblSession_AreaCount] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Session_lngSessionId] [int] NOT NULL ,
		[AreaCat_strCode] [varchar] (10) NOT NULL , 
		[Area_bytNum] [tinyint] NOT NULL ,
		[SessAC_intSeatsAvail] [int] NOT NULL CONSTRAINT DF_SYN_tblSession_AreaCount_SessAC_intSeatsAvail DEFAULT (0) ,
		[SessAC_intSeatsTotal] [int] NOT NULL CONSTRAINT DF_SYN_tblSession_AreaCount_SessAC_intSeatsTotal DEFAULT (0) ,
		[SessAC_strSeatAllocation] [varchar] (1) NOT NULL , 
		[SessAC_strAdditionalData] [varchar] (1000) NULL , 
		[SessAC_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblSession_AreaCount_SessAC_dtmStamp] DEFAULT GETDATE(), 
		CONSTRAINT [PK_SYN_tblSession_AreaCount] PRIMARY KEY  CLUSTERED 
		(
			[Cinema_strID],
			[Session_lngSessionId],
			[AreaCat_strCode],
			[Area_bytNum]
		) ,
		CONSTRAINT [FK_SYN_tblSession_AreaCount_SYN_tblSession] FOREIGN KEY 
		(
			[Cinema_strID],
			[Session_lngSessionId]
		) REFERENCES [dbo].[SYN_tblSession] (
			[Cinema_strID],
			[Session_lngSessionId]
		)
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblSession_Attribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblSession_Attribute] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Session_lngSessionId] [int] NOT NULL , 
		[Attrib_strCode] [varchar] (10) NOT NULL , 
		[Attrib_strClass] [varchar] (30) NOT NULL , 
		[Attrib_strDescription] [nvarchar] (100) NOT NULL , 
		[Attrib_strShortName] [nvarchar] (20) NULL , 
		[Attrib_strAltDescription] [nvarchar] (100) NULL , 
		[Attrib_strAltShortName] [nvarchar] (20) NULL , 
		[Attrib_strIconName] [nvarchar] (60) NULL , 
		[Attrib_strHOCode] [varchar] (10) NULL , 
		[Attrib_strStatus] [char] (1) NOT NULL,
		[Attrib_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblSession_Attribute_Attrib_dtmStamp] DEFAULT GETDATE(), 
		CONSTRAINT [PK_SYN_tblSession_Attribute] PRIMARY KEY CLUSTERED
		(
			[Cinema_strID], 
			[Session_lngSessionId], 
			[Attrib_strCode]
		), 
		CONSTRAINT [FK_SYN_tblSession_Attribute_tblSession] FOREIGN KEY ([Cinema_strID], [Session_lngSessionId]) REFERENCES [dbo].[SYN_tblSession] ([Cinema_strID], [Session_lngSessionId]), 
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblPerson]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblPerson] (
		[Film_strCode] [varchar] (20) NOT NULL , 
		[Person_strCode] [varchar] (10) NOT NULL , 
		[FPerson_strType] [varchar] (1) NOT NULL ,
		[Person_strFirstName] [nvarchar] (50) NOT NULL , 
		[Person_strLastName] [nvarchar] (50) NOT NULL , 
		[Person_strURLToDetails] [varchar] (255) NULL , 
		[Person_strURLToPicture] [varchar] (255) NULL , 
		[Person_strAdditionalData] [varchar] (1000) NULL ,
		[Person_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblPerson_Person_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblPerson] PRIMARY KEY CLUSTERED
		(
			[Film_strCode],
			[Person_strCode],
			[FPerson_strType]
		), 
		CONSTRAINT [FK_SYN_tblPerson_SYN_tblFilm] FOREIGN KEY ([Film_strCode]) REFERENCES [dbo].[SYN_tblFilm] ([Film_strCode])
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblItem_Prices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblItem_Prices] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[PriceH_strCode] [varchar] (10) NOT NULL , 
		[Item_strID] [varchar] (15) NOT NULL , 
		[Item_intPrice] [int] NOT NULL , 
		[Item_strDescription] [varchar] (255) NULL , 
		[Item_strMasterItemCode] [varchar] (15) NULL , 
		[Price_dtmEffectiveFrom] [datetime] NOT NULL , 
		[Price_dtmEffectiveTo] [datetime] NOT NULL , 
		[Price_intStartTime] [time] NOT NULL , 
		[Price_intEndTime] [time] NOT NULL , 
		[Price_strMonday] [varchar] (1) NOT NULL , 
		[Price_strTuesday] [varchar] (1) NOT NULL , 
		[Price_strWednesday] [varchar] (1) NOT NULL , 
		[Price_strThursday] [varchar] (1) NOT NULL , 
		[Price_strFriday] [varchar] (1) NOT NULL , 
		[Price_strSaturday] [varchar] (1) NOT NULL , 
		[Price_strSunday] [varchar] (1) NOT NULL , 
		[Item_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblItem_Prices_Item_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblItem_Prices] PRIMARY KEY  CLUSTERED 
		(
			[Cinema_strID],
			[PriceH_strCode],
			[Item_strID],
			[Item_intPrice]
		) , 
		CONSTRAINT [FK_SYN_tblItem_Prices_tblCinema] FOREIGN KEY 
		(
			[Cinema_strID]
		) REFERENCES [dbo].[tblCinema] (
			[Cinema_strID]
		)
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblItem_Prices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax1' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItem_Prices'))
		ALTER TABLE SYN_tblItem_Prices 
			ADD Item_intTax1 [int] NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax2' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItem_Prices'))
		ALTER TABLE SYN_tblItem_Prices 
			ADD Item_intTax2 [int] NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax3' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItem_Prices'))
		ALTER TABLE SYN_tblItem_Prices 
			ADD Item_intTax3 [int] NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax4' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItem_Prices'))
		ALTER TABLE SYN_tblItem_Prices 
			ADD Item_intTax4 [int] NULL 

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_strPackage' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItem_Prices'))
		ALTER TABLE SYN_tblItem_Prices 
			ADD Item_strPackage [varchar] (1) NULL 
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'CinOperator_strCode' AND id IN (SELECT id FROM sysobjects WHERE name = 'SYN_tblItem_Prices'))
		ALTER TABLE SYN_tblItem_Prices 
			ADD CinOperator_strCode [varchar] (10) NULL 
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblItem_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblItem_Packages] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[ItemPack_strKey] [varchar] (10) NOT NULL , 
		[Item_strID] [varchar] (15) NOT NULL , 
		[Item_strSubItemId] [varchar] (15) NOT NULL , 
		[ItemPack_intSeq] [smallint] NOT NULL , 
		[ItemPack_intQuantity] [int] NOT NULL , 
		[ItemPack_intPrice] [int] NOT NULL , 
		[ItemPack_intTax1] [int] NULL , 
		[ItemPack_intTax2] [int] NULL , 
		[ItemPack_intTax3] [int] NULL , 
		[ItemPack_intTax4] [int] NULL , 
		[ItemPack_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblBgItem_Packages_ItemPack_dtmStamp] DEFAULT GETDATE() , 
		CONSTRAINT [PK_SYN_tblItem_Packages] PRIMARY KEY  CLUSTERED 
		(
			[Cinema_strID],
			[ItemPack_strKey],
			[Item_strID]
		) , 
		CONSTRAINT [FK_SYN_tblItem_Packages_SYN_tblItems] FOREIGN KEY 
		(
			[Cinema_strID],
			[Item_strID]
		) REFERENCES [dbo].[SYN_tblItems] (
			[Cinema_strID],
			[Item_strID]
		)
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblScreen_Area]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblScreen_Area] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Area_bytNum] [smallint] NOT NULL ,
		[ScreenL_intId] [int] NOT NULL ,
		[AreaCat_strCode] [varchar] (10) NOT NULL ,
		[AreaCat_strCode_FallbackCategory]  [varchar] (10) NOT NULL ,
		[AdvBookRule_intID] [int] NOT NULL ,
		[AdvBookRule_intMinutesPrior] [int] NOT NULL,
		[ScreenArea_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblScreen_Area_ScreenArea_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblScreen_Area] PRIMARY KEY CLUSTERED
		(
			[Cinema_strID],
			[ScreenL_intId],
			[Area_bytNum]
		) ,
		CONSTRAINT [FK_SYN_tblScreen_Area_tblCinema] FOREIGN KEY
		(
			[Cinema_strID]
		) REFERENCES [dbo].[tblCinema] (
			[Cinema_strID]
		)
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE WHERE TABLE_NAME = 'SYN_tblScreen_Area' AND CONSTRAINT_NAME = 'PK_SYN_tblScreen_Area') BEGIN
	ALTER TABLE SYN_tblScreen_Area
		ADD CONSTRAINT PK_SYN_tblScreen_Area PRIMARY KEY CLUSTERED ([Cinema_strID], [ScreenL_intId], [Area_bytNum]) 
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE WHERE TABLE_NAME = 'SYN_tblScreen_Area' AND CONSTRAINT_NAME = 'FK_SYN_tblScreen_Area_tblCinema') BEGIN
	ALTER TABLE SYN_tblScreen_Area
		ADD CONSTRAINT FK_SYN_tblScreen_Area_tblCinema FOREIGN KEY ([Cinema_strID])
			REFERENCES [dbo].[tblCinema] ([Cinema_strID])
END
GO


IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[SYN_tblTicketPriceAdjustment]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[SYN_tblTicketPriceAdjustment] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Session_lngSessionId] [int] NOT NULL ,
		[AreaCat_strCode] [varchar] (10) NOT NULL ,
		[TType_strCode] [varchar] (4) NOT NULL ,
		[Price_intMinDaysAdvancePurchase] [int] NOT NULL ,
		[TPA_intTicketsRemaining] [int] NOT NULL ,
		[TPA_strIsAvailable] [varchar] (1) NOT NULL,
		[TPA_dtmStamp] [DateTime] NOT NULL CONSTRAINT [DF_SYN_tblTicketPriceAdjustment_TPA_dtmStamp] DEFAULT GETDATE(),
		CONSTRAINT [PK_SYN_tblTicketPriceAdjustment] PRIMARY KEY CLUSTERED
		(
			[Cinema_strID],
			[Session_lngSessionId],
			[AreaCat_strCode],
			[TType_strCode]
		) ,
		CONSTRAINT [FK_SYN_tblTicketPriceAdjustment_SYN_tblSession] FOREIGN KEY
		(
			[Cinema_strID],
			[Session_lngSessionId]
		) REFERENCES [dbo].[SYN_tblSession] (
			[Cinema_strID],
			[Session_lngSessionId]
		)
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE WHERE TABLE_NAME = 'SYN_tblTicketPriceAdjustment' AND CONSTRAINT_NAME = 'PK_SYN_tblTicketPriceAdjustment') BEGIN
	ALTER TABLE SYN_tblTicketPriceAdjustment
		ADD CONSTRAINT PK_SYN_tblTicketPriceAdjustment PRIMARY KEY CLUSTERED ([Cinema_strID], [Session_lngSessionId], [AreaCat_strCode], [TType_strCode]) 
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.CONSTRAINT_TABLE_USAGE WHERE TABLE_NAME = 'SYN_tblTicketPriceAdjustment' AND CONSTRAINT_NAME = 'FK_SYN_tblTicketPriceAdjustment_SYN_tblSession') BEGIN
	ALTER TABLE SYN_tblTicketPriceAdjustment
		ADD CONSTRAINT FK_SYN_tblTicketPriceAdjustment_SYN_tblSession FOREIGN KEY ([Cinema_strID], [Session_lngSessionId])
			REFERENCES [dbo].[SYN_tblSession] ([Cinema_strID], [Session_lngSessionId])
END
GO

/* *************************************************************************************************

	Script Name   : Transfer Tables Creation Script for VISTACS
	Last Modified : 16 Aug 2010 @ 11:30:00 PM
	Last Author   : Viraj Patel

************************************************************************************************* */

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[tblReconData]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[tblReconData] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Booking_lngId] [Int] NOT NULL, 
		[Booking_strName] [nVarChar] (100) NULL, 
		[Booking_strPhone] [nVarChar] (50) NULL, 
		[Booking_strPickup] [nVarChar] (50) NULL, 
		[Booking_strComments] [nVarChar] (100) NULL, 
		[Booking_mnyPaid] [Money] NULL, 
		[Booking_intTicketPrint] [SmallInt] NULL,
		[Booking_strStatus] [VarChar] (1) NULL, 
		[Trans_lngId] [Int] NULL, 
		[Booking_dtmDate] [DateTime] NULL, 
		[Booking_dtmPickupDate] [DateTime] NULL, 
		[Booking_strPickupWorkstation] [VarChar] (50) NULL, 
		[Booking_intPickupUser] [SmallInt] NULL, 
		[Trans_strWorkstation] [VarChar] (50) NULL, 
		[Trans_intUser] [SmallInt] NULL, 
		[Trans_dtmStamp] [DateTime] NULL, 
		[Trans_mnyValue] [Money] NULL, 
		[ReconData_strIsMapped] [VarChar] (2) NULL,
		[ReconData_dtmStamp] [DateTime] NOT NULL, 
		CONSTRAINT [PK_tblReconData] PRIMARY KEY CLUSTERED
		(
			[Cinema_strID], 
			[Booking_lngId], 
			[ReconData_dtmStamp]
		)
	) ON [PRIMARY]
END
GO

/* *************************************************************************************************

	Script Name   : Transfer Tables Creation Script for VISTACS
	Datebase      : VISTACS
	Last Modified : 7 Jan 2012 @ 5:20 PM
	Last Author   : Viraj Patel

************************************************************************************************* */

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgMisc]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgMisc]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgBookingFee]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgBookingFee]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgFilm]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgFilm]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgFilm_Attribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgFilm_Attribute]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgItems]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgItems]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgPrices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgPrices]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgPrices_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgPrices_Packages]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgSession]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgSession]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgSession_AreaCount]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgSession_AreaCount]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgPerson]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgPerson]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgSession_Attribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgSession_Attribute]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgItem_Prices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgItem_Prices]
--GO

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgItem_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
--	DROP TABLE [dbo].[XFER_tblBgItem_Packages]
--GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgPerson]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgPerson] (
		[Cinema_strID] [varchar] (10) NOT NULL ,
		[Film_strCode] [varchar] (10) NOT NULL , 
		[FPerson_strType] [varchar] (1) NOT NULL ,
		[Person_strCode] [varchar] (10) NOT NULL , 
		[Person_strFirstName] [nvarchar] (50) NOT NULL , 
		[Person_strLastName] [nvarchar] (50) NOT NULL , 
		[Person_strURLToDetails] [varchar] (255) NULL , 
		[Person_strURLToPicture] [varchar] (255) NULL , 
		[Person_strAdditionalData] [varchar] (1000) NULL 
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgMisc]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgMisc] (
		[Cinema_strID] [varchar] (10) NOT NULL ,
		[Data_strCode] [varchar] (50) NOT NULL ,
		[Data_strValue] [varchar] (500) NOT NULL ,
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgBookingFee]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgBookingFee] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[BFee_strCode] [varchar] (10) NOT NULL ,  
		[License_strType] [varchar] (10) NOT NULL , 
		[TType_strCode] [varchar] (10) NOT NULL , 
		[BFee_curFeeMinimum] [money] NOT NULL ,
		[BFee_curFeeMaximum] [money] NOT NULL ,
		[BFee_curFee] [money] NOT NULL 
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgFilm]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgFilm] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Film_strCode] [varchar] (10) NOT NULL , 
		[Film_strTitle] [varchar] (500) NOT NULL ,
		[Film_strCensor] [varchar] (10) NOT NULL ,
		[Film_strContent] [nvarchar] (255) NOT NULL ,
		[Film_strDescription] [varchar] (255) NOT NULL ,
		[Film_strShortName] [varchar] (10) NOT NULL ,
		[Film_strSignText] [varchar] (20) NOT NULL ,
		[Film_bytSignSequence] [tinyint] NOT NULL ,
		[FilmCat_strCode] [varchar] (10) NULL , 
		[FilmCat_strName] [varchar] (30) NULL , 
		[FilmCat_strShortName] [varchar] (10) NULL , 
		[Film_strChildren] [varchar] (1) NOT NULL ,
		[Film_intDuration] [smallint] NOT NULL ,
		[Film_strStatus] [varchar] (1) NOT NULL ,
		[Film_strATMAvailable] [char] (1) NOT NULL ,
		[Film_strShortCode] [nvarchar] (15) NOT NULL ,
		[Film_intIVRCode] [int] NOT NULL ,
		[Film_strURL1] [varchar] (255) NOT NULL ,
		[Film_strURL2] [varchar] (255) NOT NULL ,
		[Film_strVCode] [varchar] (5) NOT NULL ,
		[Film_strTitleAlt] [nvarchar] (50) NOT NULL ,
		[Film_strCensorAlt] [nvarchar] (4) NOT NULL ,
		[Film_strContentAlt] [nvarchar] (255) NOT NULL ,
		[Film_strDescriptionAlt] [nvarchar] (255) NOT NULL ,
		[Film_strShortNameAlt] [nvarchar] (10) NOT NULL ,
		[Film_strSignTextAlt] [nvarchar] (20) NOT NULL ,
		[Film_strURL1Description] [nvarchar] (100) NOT NULL ,
		[Film_strURL2Description] [nvarchar] (100) NOT NULL ,
		[Film_strURLforGraphic] [varchar] (255) NOT NULL ,
		[Film_strURLforFilmName] [varchar] (255) NOT NULL ,
		[Film_strURLforTrailer] [varchar] (255) NOT NULL ,
		[Film_strMovieFormat] [nvarchar] (30) NOT NULL ,
		[Film_strSoundFormat] [nvarchar] (30) NOT NULL ,
		[Film_mnyGross] [money] NOT NULL ,
		[Film_mnyLocalGross] [money] NOT NULL ,
		[Film_strUpcomingFlag] [varchar] (1) NOT NULL ,
		[Film_strFeatureFlag] [varchar] (1) NOT NULL ,
		[Film_strNowShowingFlag] [varchar] (1) NOT NULL ,
		[Film_dtmOpeningDate] [datetime] NOT NULL ,
		[Film_strDescriptionLong] [ntext] NOT NULL , 
		[Film_strAdditionalData] [VarChar] (1000) NULL
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgFilm]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Film_strSalesChannels' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgFilm'))
		ALTER TABLE XFER_tblBgFilm 
			ADD Film_strSalesChannels [VarChar] (500) NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgFilm_Attribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgFilm_Attribute] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Film_strCode] [varchar] (10) NOT NULL , 
		[Attrib_strCode] [varchar] (10) NOT NULL , 
		[Attrib_strClass] [varchar] (30) NOT NULL , 
		[Attrib_strDescription] [nvarchar] (100) NOT NULL , 
		[Attrib_strShortName] [nvarchar] (20) NULL , 
		[Attrib_strAltDescription] [nvarchar] (100) NULL , 
		[Attrib_strAltShortName] [nvarchar] (20) NULL , 
		[Attrib_strIconName] [nvarchar] (60) NULL , 
		[Attrib_strHOCode] [varchar] (10) NULL , 
		[Attrib_strStatus] [char] (1) NOT NULL
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgItems]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgItems] (
		[Cinema_strID] [varchar] (10) NOT NULL ,
		[Item_strID] [varchar] (15) NOT NULL ,
		[Item_strDescription] [varchar] (255) NOT NULL ,
		[Item_intPrice] [int] NOT NULL ,
		[Item_strVoiceFileName] [varchar] (12) NOT NULL ,
		[Item_strMasterItemCode] [varchar] (15) NOT NULL , 
		[Item_strAdditionalData] [varchar] (1000) NULL , 
		[Class_strCode1] [varchar] (4) NULL , 
		[Class_strDesc1] [varchar] (50) NULL , 
		[Class_strCode2] [varchar] (4) NULL , 
		[Class_strDesc2] [varchar] (50) NULL , 
		[Class_strCode3] [varchar] (4) NULL , 
		[Class_strDesc3] [varchar] (50) NULL 
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgItems]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax1' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItems'))
		ALTER TABLE XFER_tblBgItems 
			ADD Item_intTax1 [int] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax2' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItems'))
		ALTER TABLE XFER_tblBgItems 
			ADD Item_intTax2 [int] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax3' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItems'))
		ALTER TABLE XFER_tblBgItems 
			ADD Item_intTax3 [int] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax4' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItems'))
		ALTER TABLE XFER_tblBgItems 
			ADD Item_intTax4 [int] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_strPackage' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItems'))
		ALTER TABLE XFER_tblBgItems 
			ADD Item_strPackage [varchar] (1) NULL
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'CinOperator_strCode' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItems'))
		ALTER TABLE XFER_tblBgItems 
			ADD CinOperator_strCode [varchar] (10) NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgPrices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgPrices] (
		[Cinema_strID] [varchar] (10) NOT NULL ,
		[PGroup_strCode] [varchar] (4) NOT NULL ,
		[TType_strCode] [varchar] (4) NOT NULL ,
		[AreaCat_strCode] [varchar] (10) NOT NULL ,
		[BFee_strCode] [varchar] (10) NULL ,
		[TType_strDescription] [varchar] (25) NOT NULL ,
		[TType_strDescriptionAlt] [nvarchar] (25) NOT NULL ,
		[Price_intSequence] [smallint] NOT NULL ,
		[Price_curPrice] [money] NOT NULL ,
		[Price_strChildTicket] [varchar] (1) NOT NULL ,
		[Price_strPackage] [char] (1) NOT NULL ,
		[Price_strComp] [char] (1) NOT NULL ,
		[Price_dtmEffectFrom] [datetime] NULL ,
		[Price_dtmEffectTill] [datetime] NULL ,
		[Price_strQuantity] [varchar] (200) NULL ,
		[Price_strAdditionalData] [varchar] (1000) NULL 
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgPrices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_strSalesChannels' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices'))
		ALTER TABLE XFER_tblBgPrices 
			ADD Price_strSalesChannels [VarChar] (500) NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax1' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices'))
		ALTER TABLE XFER_tblBgPrices 
			ADD Price_curTax1 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax2' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices'))
		ALTER TABLE XFER_tblBgPrices 
			ADD Price_curTax2 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax3' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices'))
		ALTER TABLE XFER_tblBgPrices 
			ADD Price_curTax3 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax4' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices'))
		ALTER TABLE XFER_tblBgPrices 
			ADD Price_curTax4 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'TType_strHOCode' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices'))
		ALTER TABLE XFER_tblBgPrices 
			ADD TType_strHOCode [varchar] (10) NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgPrices_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgPrices_Packages] (
		[Cinema_strID] [varchar] (10) NOT NULL ,
		[PPack_strCode] [varchar] (10) NOT NULL ,
		[PGroup_strCode] [varchar] (4) NOT NULL ,
		[TType_strCode] [varchar] (4) NOT NULL ,
		[TType_strChildCode] [varchar] (4) NOT NULL ,
		[Item_strItemId] [varchar] (15) NOT NULL ,
		[PPack_curQuantity] [money] NOT NULL ,
		[PPack_curPriceEach] [money] NOT NULL 
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgPrices_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax1' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices_Packages'))
		ALTER TABLE XFER_tblBgPrices_Packages 
			ADD Price_curTax1 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax2' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices_Packages'))
		ALTER TABLE XFER_tblBgPrices_Packages 
			ADD Price_curTax2 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax3' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices_Packages'))
		ALTER TABLE XFER_tblBgPrices_Packages 
			ADD Price_curTax3 [money] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Price_curTax4' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgPrices_Packages'))
		ALTER TABLE XFER_tblBgPrices_Packages 
			ADD Price_curTax4 [money] NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgSession]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgSession] (
		[Cinema_strID] [varchar] (10) NOT NULL ,
		[Session_lngSessionId] [int] NOT NULL ,
		[Film_strCode] [varchar] (10) NOT NULL ,
		[Screen_bytNum] [int] NOT NULL ,
		[Layout_intId] [int] NULL , 
		[Screen_strName] [varchar] (25) NOT NULL ,
		[Session_strStatus] [varchar] (1) NOT NULL ,
		[Session_strType] [varchar] (1) NULL , 
		[Session_dtmRealShow] [datetime] NOT NULL ,
		[Session_dtmFinishShow] [datetime] NOT NULL ,
		[PGroup_strCode] [varchar] (4) NOT NULL ,
		[Session_intSeatsAvail] [int] NOT NULL ,
		[Session_intSeatsTotal] [int] NULL , 
		[Session_strSeatAllocation] [varchar] (1) NOT NULL ,
		[Session_strComments] [nvarchar] (255) NOT NULL , 
		[Session_dtmFilmFirstShow] [datetime] NULL , 
		[Session_strHOSessionID] [varchar] (10) NULL , 
		[Event_strCode] [varchar] (10) NULL , 
		[Event_strName] [nvarchar] (100) NULL , 
		[Session_strAdditionalData] [varchar] (1000) NULL 
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgSession]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Session_strSalesChannel' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgSession'))
		ALTER TABLE XFER_tblBgSession 
			ADD Session_strSalesChannel [VarChar] (500) NULL
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'CinOperator_strCode' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgSession'))
		ALTER TABLE XFER_tblBgSession 
			ADD CinOperator_strCode [VarChar] (10) NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Session_strCinemaPopUpDesc' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgSession'))
		ALTER TABLE XFER_tblBgSession 
			ADD Session_strCinemaPopUpDesc [VarChar] (2000) NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgSession_AreaCount]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgSession_AreaCount] (
		[Cinema_strID] [varchar] (10) NOT NULL ,
		[Session_lngSessionId] [int] NOT NULL ,
		[AreaCat_strCode] [varchar] (10) NOT NULL ,
		[Area_bytNum] [tinyint] NOT NULL,
		[SessAC_intSeatsAvail] [int] NOT NULL DEFAULT (0), 
		[SessAC_intSeatsTotal] [int] NOT NULL DEFAULT (0), 
		[SessAC_strSeatAllocation] [varchar] (1) NOT NULL , 
		[SessAC_strAdditionalData] [varchar] (1000) NULL 
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgSession_Attribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgSession_Attribute] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Session_lngSessionId] [int] NOT NULL , 
		[Attrib_strCode] [varchar] (10) NOT NULL , 
		[Attrib_strClass] [varchar] (30) NOT NULL , 
		[Attrib_strDescription] [nvarchar] (100) NOT NULL , 
		[Attrib_strShortName] [nvarchar] (20) NULL , 
		[Attrib_strAltDescription] [nvarchar] (100) NULL , 
		[Attrib_strAltShortName] [nvarchar] (20) NULL , 
		[Attrib_strIconName] [nvarchar] (60) NULL , 
		[Attrib_strHOCode] [varchar] (10) NULL , 
		[Attrib_strStatus] [char] (1) NOT NULL
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgItem_Prices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgItem_Prices] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[PriceH_strCode] [varchar] (10) NOT NULL , 
		[Item_strID] [int] NOT NULL , 
		[Item_intPrice] [int] NOT NULL , 
		[Item_strDescription] [varchar] (255) NOT NULL , 
		[Item_strMasterItemCode] [varchar] (15) NOT NULL , 
		[Price_dtmEffectiveFrom] [datetime] NOT NULL , 
		[Price_dtmEffectiveTo] [datetime] NOT NULL , 
		[Price_intStartTime] [time] NOT NULL , 
		[Price_intEndTime] [time] NOT NULL , 
		[Price_strMonday] [varchar] (1) NOT NULL , 
		[Price_strTuesday] [varchar] (1) NOT NULL , 
		[Price_strWednesday] [varchar] (1) NOT NULL , 
		[Price_strThursday] [varchar] (1) NOT NULL , 
		[Price_strFriday] [varchar] (1) NOT NULL , 
		[Price_strSaturday] [varchar] (1) NOT NULL , 
		[Price_strSunday] [varchar] (1) NOT NULL 
	) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgItem_Prices]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax1' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItem_Prices'))
		ALTER TABLE XFER_tblBgItem_Prices 
			ADD Item_intTax1 [int] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax2' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItem_Prices'))
		ALTER TABLE XFER_tblBgItem_Prices 
			ADD Item_intTax2 [int] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax3' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItem_Prices'))
		ALTER TABLE XFER_tblBgItem_Prices 
			ADD Item_intTax3 [int] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_intTax4' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItem_Prices'))
		ALTER TABLE XFER_tblBgItem_Prices 
			ADD Item_intTax4 [int] NULL

	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Item_strPackage' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItem_Prices'))
		ALTER TABLE XFER_tblBgItem_Prices 
			ADD Item_strPackage [varchar] (1) NULL
	
	IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'CinOperator_strCode' AND id IN (SELECT id FROM sysobjects WHERE name = 'XFER_tblBgItem_Prices'))
		ALTER TABLE XFER_tblBgItem_Prices 
			ADD CinOperator_strCode [varchar] (10) NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgItem_Packages]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgItem_Packages] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[ItemPack_strKey] [varchar] (10) NOT NULL , 
		[Item_strID] [varchar] (15) NOT NULL , 
		[Item_strSubItemId] [varchar] (15) NOT NULL , 
		[ItemPack_intSeq] [smallint] NOT NULL , 
		[ItemPack_intQuantity] [int] NOT NULL , 
		[ItemPack_intPrice] [int] NOT NULL , 
		[ItemPack_intTax1] [int] NULL , 
		[ItemPack_intTax2] [int] NULL , 
		[ItemPack_intTax3] [int] NULL , 
		[ItemPack_intTax4] [int] NULL 
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgScreen_Area]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgScreen_Area] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Area_bytNum] [smallint] NOT NULL ,
		[ScreenL_intId] [int] NOT NULL ,
		[AreaCat_strCode] [varchar] (10) NOT NULL ,
		[AreaCat_strCode_FallbackCategory]  [varchar] (10) NOT NULL ,
		[AdvBookRule_intID] [int] NOT NULL ,
		[AdvBookRule_intMinutesPrior] [int] NOT NULL
	) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[XFER_tblBgTicketPriceAdjustment]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN
	CREATE TABLE [dbo].[XFER_tblBgTicketPriceAdjustment] (
		[Cinema_strID] [varchar] (10) NOT NULL , 
		[Session_lngSessionId] [int] NOT NULL ,
		[AreaCat_strCode] [varchar] (10) NOT NULL ,
		[TType_strCode] [varchar] (4) NOT NULL ,
		[Price_intMinDaysAdvancePurchase] [int] NOT NULL ,
		[TPA_intTicketsRemaining] [int] NOT NULL ,
		[TPA_strIsAvailable] [varchar] (1) NOT NULL
	) ON [PRIMARY]
END
GO

/*********************************************************************************************

	Procedure Name    : spDeleteXFERTables
	Database          : VISTACS
	Last Modified     : 26 Apr 2018 @ 12:57 PM
	Last Author       : Praveenkumar Bodhuna

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spDeleteXFERTables]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spDeleteXFERTables]
GO

CREATE PROCEDURE [dbo].[spDeleteXFERTables]
	@strCinemaId As VarChar(10)
	WITH ENCRYPTION
AS BEGIN

	DELETE FROM XFER_tblBgSession_Attribute WHERE Cinema_strID = @strCinemaId

	DELETE FROM XFER_tblBgSession_AreaCount WHERE Cinema_strID = @strCinemaId

	DELETE FROM XFER_tblBgSession WHERE Cinema_strID = @strCinemaId

	DELETE FROM XFER_tblBgPrices_Packages WHERE Cinema_strID = @strCinemaId 

	DELETE FROM XFER_tblBgPrices WHERE Cinema_strID = @strCinemaId 

	DELETE FROM XFER_tblBgItems WHERE Cinema_strID = @strCinemaId 

	DELETE FROM XFER_tblBgPerson WHERE Cinema_strID = @strCinemaId

	DELETE FROM XFER_tblBgFilm WHERE Cinema_strID = @strCinemaId 

	DELETE FROM XFER_tblBgBookingFee WHERE Cinema_strID = @strCinemaId 

	DELETE FROM XFER_tblBgMisc WHERE Cinema_strID = @strCinemaId
	
	DELETE FROM XFER_tblBgFilm_Attribute WHERE Cinema_strID = @strCinemaId
	
	DELETE FROM XFER_tblBgItem_Prices WHERE Cinema_strID = @strCinemaId 
	
	DELETE FROM XFER_tblBgItem_Packages WHERE Cinema_strID = @strCinemaId 
	
	DELETE FROM XFER_tblBgScreen_Area WHERE Cinema_strID = @strCinemaId
	
	DELETE FROM XFER_tblBgTicketPriceAdjustment WHERE Cinema_strID = @strCinemaId

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertFilm
	Database          : VISTACS
	Last Modified     : 21 Nov 2011 @ 6:00 PM
	Last Author       : Viraj Patel

*********************************************************************************************/

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[sp_InsertFilm]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
--	DROP PROCEDURE [dbo].[sp_InsertFilm]
--GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertFilm]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertFilm]
GO

CREATE PROCEDURE [dbo].[spInsertFilm]
	@Cinema_strID AS varchar (10), 
	@Film_strCode AS varchar (10),
	@Film_strTitle AS varchar (50),
	@Film_strCensor AS varchar (4),
	@Film_strContent AS nvarchar (255),
	@Film_strDescription AS varchar (255),
	@Film_strShortName AS varchar (10),
	@Film_strSignText AS varchar (20),
	@Film_bytSignSequence AS tinyint,
	@FilmCat_strCode As varchar(10) = '', 
	@FilmCat_strName As varchar(30) = '', 
	@FilmCat_strShortName As varchar(10) = '', 
	@Film_strChildren AS varchar (1),
	@Film_intDuration AS smallint,
	@Film_strStatus AS varchar (1),
	@Film_strATMAvailable AS char (1),
	@Film_strShortCode AS nvarchar (15),
	@Film_intIVRCode AS int,
	@Film_strURL1 AS varchar (255),
	@Film_strURL2 AS varchar (255),
	@Film_strVCode AS varchar (5),
	@Film_strTitleAlt AS nvarchar (50),
	@Film_strCensorAlt AS nvarchar (4),
	@Film_strContentAlt AS nvarchar (255),
	@Film_strDescriptionAlt AS nvarchar (255),
	@Film_strShortNameAlt AS nvarchar (10),
	@Film_strSignTextAlt AS nvarchar (20),
	@Film_strURL1Description AS nvarchar (100),
	@Film_strURL2Description AS nvarchar (100),
	@Film_strURLforGraphic AS varchar (255),
	@Film_strURLforFilmName AS varchar (255),
	@Film_strURLforTrailer AS varchar (255),
	@Film_strMovieFormat AS nvarchar (30),
	@Film_strSoundFormat AS nvarchar (30),
	@Film_mnyGross AS money,
	@Film_mnyLocalGross AS money,
	@Film_strUpcomingFlag  AS varchar (1),
	@Film_strFeatureFlag AS varchar (1),
	@Film_strNowShowingFlag AS varchar (1),
	@Film_dtmOpeningDate AS datetime,
	@Film_strDescriptionLong ntext, 
	@Film_strAdditionalData As varchar (1000) = NULL,
	@Film_strSalesChannels As varchar (500) = NULL,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgFilm (Cinema_strID, Film_strCode, Film_strTitle, Film_strCensor, Film_strContent, Film_strDescription, Film_strShortName, Film_strSignText, Film_bytSignSequence, Film_strChildren, Film_intDuration, Film_strStatus, Film_strATMAvailable, Film_strShortCode, Film_intIVRCode, Film_strURL1, Film_strURL2, Film_strVCode, Film_strTitleAlt, Film_strCensorAlt, Film_strContentAlt, Film_strDescriptionAlt, Film_strShortNameAlt, Film_strSignTextAlt, Film_strURL1Description, Film_strURL2Description, Film_strURLforGraphic, Film_strURLforFilmName, Film_strURLforTrailer, Film_strMovieFormat, Film_strSoundFormat, Film_mnyGross, Film_mnyLocalGross, Film_strUpcomingFlag, Film_strFeatureFlag, Film_strNowShowingFlag, Film_dtmOpeningDate, Film_strDescriptionLong, FilmCat_strCode, FilmCat_strName, FilmCat_strShortName, Film_strAdditionalData, Film_strSalesChannels) 
	VALUES (@Cinema_strID, @Film_strCode, @Film_strTitle, @Film_strCensor, @Film_strContent, @Film_strDescription, @Film_strShortName, @Film_strSignText, @Film_bytSignSequence, @Film_strChildren, @Film_intDuration, @Film_strStatus, @Film_strATMAvailable, @Film_strShortCode, @Film_intIVRCode, @Film_strURL1, @Film_strURL2, @Film_strVCode, @Film_strTitleAlt, @Film_strCensorAlt, @Film_strContentAlt, @Film_strDescriptionAlt, @Film_strShortNameAlt, @Film_strSignTextAlt, @Film_strURL1Description, @Film_strURL2Description, @Film_strURLforGraphic, @Film_strURLforFilmName, @Film_strURLforTrailer, @Film_strMovieFormat, @Film_strSoundFormat, @Film_mnyGross, @Film_mnyLocalGross, @Film_strUpcomingFlag, @Film_strFeatureFlag, @Film_strNowShowingFlag, @Film_dtmOpeningDate, @Film_strDescriptionLong, @FilmCat_strCode, @FilmCat_strName, @FilmCat_strShortName, @Film_strAdditionalData, @Film_strSalesChannels)

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertBookingFee
	Database          : VISTACS
	Last Modified     : 23 Mar 2007 @ 8:00 PM
	Last Author       : Viraj Patel

*********************************************************************************************/

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[sp_InsertBookingFee]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
--	DROP PROCEDURE [dbo].[sp_InsertBookingFee]
--GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertBookingFee]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertBookingFee]
GO

CREATE PROCEDURE [dbo].[spInsertBookingFee]
	@Cinema_strID AS varchar (10),
	@BFee_strCode AS varchar (10),
	@License_strType AS varchar (10),
	@TType_strCode AS varchar (10),
	@BFee_curFeeMinimum AS money,
	@BFee_curFeeMaximum AS money,
	@BFee_curFee AS money,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgBookingFee (Cinema_strID, BFee_strCode, License_strType, TType_strCode, BFee_curFeeMinimum, BFee_curFeeMaximum, BFee_curFee) 
		VALUES (@Cinema_strID, @BFee_strCode, @License_strType, @TType_strCode, @BFee_curFeeMinimum, @BFee_curFeeMaximum, @BFee_curFee)

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertItem
	Database          : VISTACS
	Last Modified     : 2 Aug 2017 @ 12:00 PM
	Last Author       : Praveen Bodhuna

**********************************************************************************************/

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[sp_InsertItem]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
--	DROP PROCEDURE [dbo].[sp_InsertItem]
--GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertItem]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertItem]
GO

CREATE PROCEDURE [dbo].[spInsertItem]
	@Cinema_strID AS varchar (10),
	@Item_strID AS varchar (15),
	@Item_strDescription AS varchar (255),
	@Item_intPrice AS int,
	@Item_strVoiceFileName AS varchar (12),
	@Item_strMasterItemCode AS varchar (15), 
	@Item_strAdditionalData AS varchar (1000) = NULL, 
	@Class_strCode1 AS varchar (4) = NULL , 
	@Class_strDesc1 AS varchar (50) = NULL , 
	@Class_strCode2 AS varchar (4) = NULL , 
	@Class_strDesc2 AS varchar (50) = NULL , 
	@Class_strCode3 AS varchar (4) = NULL , 
	@Class_strDesc3 AS varchar (50) = NULL,
	@Item_intTax1 AS int = NULL,
	@Item_intTax2 AS int = NULL,
	@Item_intTax3 AS int = NULL,
	@Item_intTax4 AS int = NULL,
	@Item_strPackage AS varchar (1) = NULL,
	@CinOperator_strCode As varchar (10) = NULL,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgItems (Cinema_strID, Item_strID, Item_strDescription, Item_intPrice, Item_strVoiceFileName, Item_strMasterItemCode, Item_strAdditionalData, Class_strCode1, Class_strDesc1, Class_strCode2, Class_strDesc2, Class_strCode3, Class_strDesc3, Item_intTax1, Item_intTax2, Item_intTax3, Item_intTax4, Item_strPackage, CinOperator_strCode)
	VALUES (@Cinema_strID, @Item_strID, @Item_strDescription, @Item_intPrice, @Item_strVoiceFileName, @Item_strMasterItemCode, @Item_strAdditionalData, @Class_strCode1, @Class_strDesc1, @Class_strCode2, @Class_strDesc2, @Class_strCode3, @Class_strDesc3, ISNULL(@Item_intTax1, 0), ISNULL(@Item_intTax2, 0), ISNULL(@Item_intTax3, 0), ISNULL(@Item_intTax4, 0), ISNULL(@Item_strPackage, 'N'), @CinOperator_strCode)

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertPricePackages
	Database          : VISTACS
	Last Modified     : 10 Aug 2017 @ 4:02 PM
	Last Author       : Praveen Bodhuna

**********************************************************************************************/

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[sp_InsertPricePackages]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
--	DROP PROCEDURE [dbo].[sp_InsertPricePackages]
--GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertPricePackages]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertPricePackages]
GO

CREATE PROCEDURE [dbo].[spInsertPricePackages]
	@Cinema_strID As varchar (10),
	@PPack_strCode As varchar (10),
	@PGroup_strCode AS varchar (4),
	@TType_strCode AS varchar (4),
	@TType_strChildCode AS varchar (4),
	@Item_strItemId AS varchar  (15),
	@PPack_curQuantity AS money,
	@PPack_curPriceEach AS money,
	@Price_curTax1 As money = NULL,
	@Price_curTax2 As money = NULL,
	@Price_curTax3 As money = NULL,
	@Price_curTax4 As money = NULL,
	@Cinema_strClientId As varchar(20) = NULL
	
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgPrices_Packages (Cinema_strID, PPack_strCode, PGroup_strCode, TType_strCode, TType_strChildCode, Item_strItemId, PPack_curQuantity, PPack_curPriceEach, Price_curTax1, Price_curTax2, Price_curTax3, Price_curTax4)
		VALUES (@Cinema_strID, @PPack_strCode, @PGroup_strCode, @TType_strCode, @TType_strChildCode, @Item_strItemId, @PPack_curQuantity, @PPack_curPriceEach, ISNULL(@Price_curTax1, 0), ISNULL(@Price_curTax2, 0), ISNULL(@Price_curTax3, 0), ISNULL(@Price_curTax4, 0))

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertPrices
	Database          : VISTACS
	Last Modified     : 2 Aug 2017 @ 12:00 PM
	Last Author       : Praveen Bodhuna

*********************************************************************************************/

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[sp_InsertPrices]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
--	DROP PROCEDURE [dbo].[sp_InsertPrices]
--GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertPrices]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertPrices]
GO

CREATE PROCEDURE [dbo].[spInsertPrices] 
	@Cinema_strID AS varchar (10) ,
	@PGroup_strCode AS varchar (4) ,
	@TType_strCode AS varchar(4) ,
	@AreaCat_strCode As varchar (10) ,
	@BFee_strCode AS varchar (10) = NULL , 
	@TType_strDescription AS varchar (25) ,
	@TType_strDescriptionAlt AS nvarchar (25) ,
	@Price_intSequence AS smallint,
	@Price_curPrice AS money,
	@Price_strChildTicket As varchar (1) ,
	@Price_strPackage AS char (1) ,
	@Price_strComp AS char (1) , 
	@Price_dtmEffectFrom As datetime = NULL,
	@Price_dtmEffectTill As datetime = NULL, 
	@Price_strQuantity As varchar(200) = NULL, 
	@Price_strAdditionalData As varchar (1000) = NULL,
	@Price_strSalesChannels As varchar (500) = NULL,
	@Price_curTax1 AS money = NULL,
	@Price_curTax2 AS money = NULL,
	@Price_curTax3 AS money = NULL,
	@Price_curTax4 AS money = NULL,
	@TType_strHOCode AS varchar(10) = NULL,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgPrices ( Cinema_strID,  PGroup_strCode,  TType_strCode,  AreaCat_strCode,  BFee_strCode,  TType_strDescription,  TType_strDescriptionAlt,  Price_intSequence,  Price_curPrice, Price_strChildTicket,  Price_strPackage,  Price_strComp,  Price_dtmEffectFrom,  Price_dtmEffectTill,  Price_strQuantity,  Price_strAdditionalData, Price_strSalesChannels, Price_curTax1, Price_curTax2, Price_curTax3, Price_curTax4, TType_strHOCode)
	VALUES                       (@Cinema_strID, @PGroup_strCode, @TType_strCode, @AreaCat_strCode, @BFee_strCode, @TType_strDescription, @TType_strDescriptionAlt, @Price_intSequence, @Price_curPrice, @Price_strChildTicket, @Price_strPackage, @Price_strComp, @Price_dtmEffectFrom, @Price_dtmEffectTill, @Price_strQuantity, @Price_strAdditionalData, @Price_strSalesChannels, ISNULL(@Price_curTax1, 0), ISNULL(@Price_curTax2, 0), ISNULL(@Price_curTax3, 0), ISNULL(@Price_curTax4, 0), @TType_strHOCode)

END
GO

/*********************************************************************************************

	Procedure Name: spInsertSession
	Last Modified : 7 Jan 2012 @ 5:20 PM
	Last Author:    Viraj Patel

**********************************************************************************************/

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[sp_InsertSession]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
--	DROP PROCEDURE [dbo].[sp_InsertSession]
--GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertSession]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertSession]
GO

CREATE PROCEDURE [dbo].[spInsertSession]
	@Cinema_strID AS varchar (10),
	@Session_lngSessionId AS int,
	@Film_strCode AS varchar (10),
	@Screen_bytNum AS Int,
	@Layout_intId As Int = NULL, 
	@Screen_strName AS varchar (25),
	@Session_strStatus AS varchar(1),
	@Session_strType AS varchar(1) = 'N',
	@Session_dtmRealShow AS datetime,
	@Session_dtmFinishShow AS datetime,
	@PGroup_strCode As varchar(4),
	@Session_intSeatsAvail AS int, 
	@Session_intSeatsTotal As int = 0, 
	@Session_strSeatAllocation AS varchar (1),
	@Session_strComments AS varchar (255),
	@Session_dtmFilmFirstShow As DateTime, 
	@Session_strHOSessionID As varchar(10) = '', 
	@Event_strCode As VarChar(10) = NULL, 
	@Event_strName As nVarChar(100) = NULL , 
	@Session_strAdditionalData As VarChar(1000) = NULL,
	@Session_strSalesChannel As varchar(500) = NULL,
	@CinOperator_strCode As varchar (10) = NULL,
	@Session_strCinemaPopUpDesc As varchar(2000) = NULL,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgSession (Cinema_strID, Session_lngSessionId, Film_strCode, Screen_bytNum, Layout_intId, Screen_strName, Session_strStatus, Session_strType, Session_dtmRealShow, Session_dtmFinishShow, PGroup_strCode, Session_intSeatsAvail, Session_intSeatsTotal, Session_strSeatAllocation, Session_strComments, Session_dtmFilmFirstShow, Session_strHOSessionID, Event_strCode, Event_strName, Session_strAdditionalData, Session_strSalesChannel, CinOperator_strCode, Session_strCinemaPopUpDesc)
		VALUES (@Cinema_strID, @Session_lngSessionId, @Film_strCode, @Screen_bytNum, @Layout_intId, @Screen_strName, @Session_strStatus,  @Session_strType, @Session_dtmRealShow, @Session_dtmFinishShow, @PGroup_strCode, @Session_intSeatsAvail, @Session_intSeatsTotal, @Session_strSeatAllocation, @Session_strComments, @Session_dtmFilmFirstShow, @Session_strHOSessionID, @Event_strCode, @Event_strName, @Session_strAdditionalData, @Session_strSalesChannel, @CinOperator_strCode, @Session_strCinemaPopUpDesc)

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertSessionArea
	Database          : VISTACS
	Last Modified     : 21 Nov 2011 @ 6:00 PM
	Last Author       : Viraj Patel

**********************************************************************************************/

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[sp_InsertSessionArea]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
--	DROP PROCEDURE [dbo].[sp_InsertSessionArea]
--GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertSessionArea]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertSessionArea]
GO

CREATE PROCEDURE [dbo].[spInsertSessionArea]
	@Cinema_strID AS varchar (10) ,
	@Session_lngSessionId AS int,
	@AreaCat_strCode AS varchar (10) ,
	@Area_bytNum as tinyint,
	@SessAC_intSeatsAvail AS Int, 
	@SessAC_intSeatsTotal As Int = 0,
	@SessAC_strSeatAllocation As VarChar(1) = '', 
	@SessAC_strAdditionalData As VarChar (1000) = NULL,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgSession_AreaCount (Cinema_strID, Session_lngSessionId, AreaCat_strCode, Area_bytNum, SessAC_intSeatsAvail, SessAC_intSeatsTotal, SessAC_strSeatAllocation, SessAC_strAdditionalData)
		VALUES (@Cinema_strID, @Session_lngSessionId, @AreaCat_strCode, @Area_bytNum, @SessAC_intSeatsAvail, @SessAC_intSeatsTotal, ISNULL(@SessAC_strSeatAllocation, ''), @SessAC_strAdditionalData)

END
GO


/*********************************************************************************************

	Procedure Name    : spInsertMisc
	Database          : VISTACS
	Last Modified     : 15 Feb 2008 @ 9:15 PM
	Last Author       : Viraj Patel

**********************************************************************************************/

--IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[sp_InsertMisc]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
--	DROP PROCEDURE [dbo].[sp_InsertMisc]
--GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertMisc]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertMisc]
GO

CREATE PROCEDURE [dbo].[spInsertMisc]
	@Cinema_strID AS varchar (10), 
	@Data_strCode AS VarChar (50) ,
	@Data_strValue AS VarChar(500),
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgMisc (Cinema_strID, Data_strCode, Data_strValue)
		VALUES (@Cinema_strID, @Data_strCode, @Data_strValue)

END
GO


/*********************************************************************************************

	Procedure Name    : spInsertMisc
	Database          : VISTACS
	Last Modified     : 21 Nov 2011 @ 6:00 PM
	Last Author       : Viraj Patel

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertPerson]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertPerson]
GO

CREATE PROCEDURE [dbo].[spInsertPerson]
	@Cinema_strID As varchar (10), 
	@Film_strCode As VarChar (10),
	@FPerson_strType As VarChar (1),
	@Person_strCode As VarChar (10),
	@Person_strFirstName As nVarChar (50),
	@Person_strLastName As nVarChar (50),
	@Person_strURLToDetails As VarChar (255) = NULL,
	@Person_strURLToPicture As VarChar (255) = NULL, 
	@Person_strAdditionalData As VarChar (1000) = NULL,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgPerson (Cinema_strID, Film_strCode, FPerson_strType, Person_strCode, Person_strFirstName, Person_strLastName, Person_strURLToDetails, Person_strURLToPicture, Person_strAdditionalData)
		VALUES (@Cinema_strID, @Film_strCode, @FPerson_strType, @Person_strCode, @Person_strFirstName, @Person_strLastName, @Person_strURLToDetails, @Person_strURLToPicture, @Person_strAdditionalData)

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertMisc
	Database          : VISTACS
	Last Modified     : 28 Dec 2011 @ 10:30 PM
	Last Author       : Viraj Patel

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertSessionAttrib]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertSessionAttrib]
GO

CREATE PROCEDURE [dbo].[spInsertSessionAttrib]
	@Cinema_strID As varchar (10), 
	@Session_lngSessionId As Int, 
	@Attrib_strCode As varchar (10), 
	@Attrib_strClass As varchar(30), 
	@Attrib_strDescription As nvarchar (100), 
	@Attrib_strShortName As nvarchar (20) = NULL, 
	@Attrib_strAltDescription As nvarchar (100) = NULL, 
	@Attrib_strAltShortName As nvarchar (20) = NULL, 
	@Attrib_strIconName As nvarchar (60) = NULL, 
	@Attrib_strHOCode As varchar (10) = NULL, 
	@Attrib_strStatus As char (1) = NULL,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgSession_Attribute (Cinema_strID, Session_lngSessionId, Attrib_strCode, Attrib_strClass, Attrib_strDescription, Attrib_strShortName, Attrib_strAltDescription, Attrib_strAltShortName, Attrib_strIconName, Attrib_strHOCode, Attrib_strStatus)
		VALUES (@Cinema_strID, @Session_lngSessionId, @Attrib_strCode, @Attrib_strClass, @Attrib_strDescription, @Attrib_strShortName, @Attrib_strAltDescription, @Attrib_strAltShortName, @Attrib_strIconName, @Attrib_strHOCode, @Attrib_strStatus)

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertMisc
	Database          : VISTACS
	Last Modified     : 28 Dec 2011 @ 10:30 PM
	Last Author       : Viraj Patel

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertFilmAttrib]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertFilmAttrib]
GO

CREATE PROCEDURE [dbo].[spInsertFilmAttrib]
	@Cinema_strID As varchar (10), 
	@Film_strCode As varchar(20), 
	@Attrib_strCode As varchar (10), 
	@Attrib_strClass As varchar(30), 
	@Attrib_strDescription As nvarchar (100), 
	@Attrib_strShortName As nvarchar (20) = NULL, 
	@Attrib_strAltDescription As nvarchar (100) = NULL, 
	@Attrib_strAltShortName As nvarchar (20) = NULL, 
	@Attrib_strIconName As nvarchar (60) = NULL, 
	@Attrib_strHOCode As varchar (10) = NULL, 
	@Attrib_strStatus As char (1) = NULL,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgFilm_Attribute (Cinema_strID, Film_strCode, Attrib_strCode, Attrib_strClass, Attrib_strDescription, Attrib_strShortName, Attrib_strAltDescription, Attrib_strAltShortName, Attrib_strIconName, Attrib_strHOCode, Attrib_strStatus)
		VALUES (@Cinema_strID, @Film_strCode, @Attrib_strCode, @Attrib_strClass, @Attrib_strDescription, @Attrib_strShortName, @Attrib_strAltDescription, @Attrib_strAltShortName, @Attrib_strIconName, @Attrib_strHOCode, @Attrib_strStatus)

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertItemPrices
	Database          : VISTACS
	Last Modified     : 02 Aug 2017 @ 12:00 PM
	Last Author       : Praveen Bodhuna

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertItemPrices]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertItemPrices]
GO

CREATE PROCEDURE [dbo].[spInsertItemPrices]
	@Cinema_strID As varchar (10),
	@PriceH_strCode As varchar (10),
	@Item_strID As varchar (15),
	@Item_intPrice As int,
	@Item_strDescription As varchar (255),
	@Item_strMasterItemCode As varchar (15), 
	@Price_dtmEffectiveFrom As datetime,
	@Price_dtmEffectiveTo As datetime,
	@Price_intStartTime As time,
	@Price_intEndTime As time,
	@Price_strMonday As varchar (1),
	@Price_strTuesday As varchar (1),
	@Price_strWednesday As varchar (1),
	@Price_strThursday As varchar (1),
	@Price_strFriday As varchar (1),
	@Price_strSaturday As varchar (1),
	@Price_strSunday As varchar (1),
	@Item_intTax1 AS int = NULL,
	@Item_intTax2 AS int = NULL,
	@Item_intTax3 AS int = NULL,
	@Item_intTax4 AS int = NULL,
	@Item_strPackage AS varchar (1) = NULL,
	@CinOperator_strCode As varchar (10) = NULL,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgItem_Prices WITH(ROWLOCK) (Cinema_strID, PriceH_strCode, Item_strID, Item_intPrice, Item_strDescription, Item_strMasterItemCode, Price_dtmEffectiveFrom, Price_dtmEffectiveTo, Price_intStartTime, Price_intEndTime, Price_strMonday, Price_strTuesday, Price_strWednesday, Price_strThursday, Price_strFriday, Price_strSaturday, Price_strSunday, Item_intTax1, Item_intTax2, Item_intTax3, Item_intTax4, Item_strPackage, CinOperator_strCode)
	VALUES (@Cinema_strID, @PriceH_strCode, @Item_strID, @Item_intPrice, @Item_strDescription, @Item_strMasterItemCode, @Price_dtmEffectiveFrom, @Price_dtmEffectiveTo, @Price_intStartTime, @Price_intEndTime, @Price_strMonday, @Price_strTuesday, @Price_strWednesday, @Price_strThursday, @Price_strFriday, @Price_strSaturday, @Price_strSunday, ISNULL(@Item_intTax1, 0), ISNULL(@Item_intTax2, 0), ISNULL(@Item_intTax3, 0), ISNULL(@Item_intTax4, 0), ISNULL(@Item_strPackage, 'N'), @CinOperator_strCode)

END
GO

/*********************************************************************************************

	Procedure Name    : spInsertItemPackages
	Database          : VISTACS
	Last Modified     : 14 Aug 2017 @ 6:00 PM
	Last Author       : Praveen Bodhuna

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertItemPackages]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertItemPackages]
GO

CREATE PROCEDURE [dbo].[spInsertItemPackages]
	@Cinema_strID As varchar (10),
	@ItemPack_strKey As varchar (10), 
	@Item_strID As varchar (15), 
	@Item_strSubItemId As varchar (15), 
	@ItemPack_intSeq As smallint, 
	@ItemPack_intQuantity As int, 
	@ItemPack_intPrice As int, 
	@ItemPack_intTax1 As int, 
	@ItemPack_intTax2 As int, 
	@ItemPack_intTax3 As int, 
	@ItemPack_intTax4 As int,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgItem_Packages (Cinema_strID, ItemPack_strKey, Item_strID, Item_strSubItemId, ItemPack_intSeq, ItemPack_intQuantity, ItemPack_intPrice, ItemPack_intTax1, ItemPack_intTax2, ItemPack_intTax3, ItemPack_intTax4)
	VALUES (@Cinema_strID , @ItemPack_strKey, @Item_strID, @Item_strSubItemId, @ItemPack_intSeq, @ItemPack_intQuantity, @ItemPack_intPrice, @ItemPack_intTax1, @ItemPack_intTax2, @ItemPack_intTax3, @ItemPack_intTax4)
	
END
GO

/*********************************************************************************************

	Procedure Name    : spInsertScreenArea
	Database          : VISTACS
	Last Modified     : 11 Apr 2018 @ 5:31 PM
	Last Author       : Praveen Bodhuna

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertScreenArea]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertScreenArea]
GO

CREATE PROCEDURE [dbo].[spInsertScreenArea]
	@Cinema_strID As varchar (10),
	@Area_bytNum As smallint, 
	@ScreenL_intId As int, 
	@AreaCat_strCode As varchar (10), 
	@AreaCat_strCode_FallbackCategory As varchar (10), 
	@AdvBookRule_intID As int, 
	@AdvBookRule_intMinutesPrior As int,
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgScreen_Area (Cinema_strID, Area_bytNum, ScreenL_intId, AreaCat_strCode, AreaCat_strCode_FallbackCategory, AdvBookRule_intID, AdvBookRule_intMinutesPrior)
		VALUES (@Cinema_strID, @Area_bytNum, @ScreenL_intId, @AreaCat_strCode, @AreaCat_strCode_FallbackCategory, @AdvBookRule_intID, @AdvBookRule_intMinutesPrior)
END
GO

/*********************************************************************************************

	Procedure Name    : spInsertTicketPriceAdjustment
	Database          : VISTACS
	Last Modified     : 11 Apr 2018 @ 5:31 PM
	Last Author       : Praveen Bodhuna

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spInsertTicketPriceAdjustment]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spInsertTicketPriceAdjustment]
GO

CREATE PROCEDURE [dbo].[spInsertTicketPriceAdjustment]
	@Cinema_strID As varchar (10),
	@Session_lngSessionId As int, 
	@AreaCat_strCode As varchar (10), 
	@TType_strCode As varchar (4), 
	@Price_intMinDaysAdvancePurchase As int, 
	@TPA_intTicketsRemaining As int,
	@TPA_strIsAvailable As varchar(1),
	@Cinema_strClientId As varchar(20) = NULL
WITH ENCRYPTION
AS BEGIN

	INSERT INTO XFER_tblBgTicketPriceAdjustment (Cinema_strID, Session_lngSessionId, AreaCat_strCode, TType_strCode, Price_intMinDaysAdvancePurchase, TPA_intTicketsRemaining, TPA_strIsAvailable)
		VALUES (@Cinema_strID, @Session_lngSessionId, @AreaCat_strCode, @TType_strCode, @Price_intMinDaysAdvancePurchase, @TPA_intTicketsRemaining,	@TPA_strIsAvailable)
END
GO

/*********************************************************************************************

	Procedure Name : spUpdateSyncTables
	Last Modified  : 11 May 2012 @ 11:30 PM
	Last Author    : Viraj Patel

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spUpdateSyncTables]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spUpdateSyncTables]
GO

CREATE PROCEDURE [dbo].[spUpdateSyncTables] 
	@strCinemaID As VarChar (10),
	@strLicenseType As VarChar(10)
WITH ENCRYPTION
AS BEGIN

	DECLARE @strFilmCodePrefix As VarChar(10)
	DECLARE @strScreenList As VarChar(1300)
	DECLARE @strUseHOCode As VarChar(1) 
	DECLARE @bytScreen As SmallInt

	SELECT @strFilmCodePrefix = UPPER(Cinema_strCompanyCode), @strScreenList = LTRIM(RTRIM(ISNULL(Cinema_strScreenList, ''))), @strUseHOCode = ISNULL(Cinema_strUseHOCode, 'N') FROM tblCinema WITH(NOLOCK) WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)

	-- Deleting extra data imported which will raise FK conflict
	
	DELETE XFER_tblBgSession_Attribute WHERE Cinema_strID = @strCinemaID AND Session_lngSessionId NOT IN (SELECT Session_lngSessionId FROM XFER_tblBgSession WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

	IF @strUseHOCode <> 'Y' SELECT @strFilmCodePrefix = @strCinemaID

	-- First DELETE the SYN Tables

	DELETE FROM SYN_tblSession_Attribute WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)

	DELETE FROM SYN_tblSession_AreaCount WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)
	
	DELETE FROM SYN_tblTicketPriceAdjustment WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)

	DELETE FROM SYN_tblSession WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)

	DELETE FROM SYN_tblPrices_Packages WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)

	DELETE FROM SYN_tblPrices WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)

	DELETE FROM SYN_tblBookingFee WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)
	
	DELETE FROM SYN_tblItem_Packages WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)

	DELETE FROM SYN_tblItems WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)
	
	DELETE FROM SYN_tblItem_Prices WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)
	
	DELETE FROM SYN_tblScreen_Area WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)

	--DELETE FROM SYN_tblPerson WHERE LOWER(Cinema_strID) = LOWER(@strCinemaID)

	--DELETE FROM SYN_tblFilm WHERE (LOWER(Film_strCode) NOT IN (SELECT DISTINCT LOWER(Film_strCode) FROM SYN_tblSession)) AND (NOT (UPPER(Film_strUpcomingFlag) = 'Y' AND Film_dtmOpeningDate > GETDATE()))

	-- Delete all the records which are NOT meant for this Cinema (at times data comes for all screens even after specifing correct ScreenList)

	IF LEN(@strScreenList) > 0 BEGIN

		CREATE TABLE #TmpScreenList(Screen_bytNum SmallInt)
		
		--Added code for '|' delimited strScreenList of size 1300
		DECLARE @sntStartPos AS SMALLINT
		DECLARE @sntEndPos AS SMALLINT
		WHILE LEN(@strScreenList) > 0 BEGIN
			IF CHARINDEX('|', @strScreenList, 1) > 0 BEGIN
				SET @sntStartPos = CHARINDEX('|', @strScreenList)
				SET @sntEndPos = CHARINDEX('|', @strScreenList, (@sntStartPos + 1))
				IF @sntStartPos > 0 AND @sntEndPos > @sntStartPos BEGIN
					SET @bytScreen = CONVERT(SmallInt, SUBSTRING(@strScreenList, @sntStartPos + 1, (@sntEndPos - 2)))
					INSERT INTO #TmpScreenList (Screen_bytNum) VALUES (@bytScreen)
					SET @strScreenList = SUBSTRING(@strScreenList, @sntEndPos, LEN(@strScreenList))
				END ELSE BEGIN
					SET @strScreenList = ''
				END
			END ELSE BEGIN
				SET @bytScreen = CONVERT(SmallInt, SUBSTRING(@strScreenList, 1, 2))
				INSERT INTO #TmpScreenList (Screen_bytNum) VALUES (@bytScreen)
				SET @strScreenList = SUBSTRING(@strScreenList, 3, LEN(@strScreenList))
			END
		END

		DELETE XFER_tblBgSession WHERE Cinema_strID = @strCinemaID AND Screen_bytNum NOT IN (SELECT Screen_bytNum FROM #TmpScreenList)

		DELETE XFER_tblBgSession_AreaCount WHERE Cinema_strID = @strCinemaID AND Session_lngSessionId NOT IN (SELECT Session_lngSessionId FROM XFER_tblBgSession WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

		DELETE XFER_tblBgPrices WHERE Cinema_strID = @strCinemaID AND PGroup_strCode NOT IN (SELECT DISTINCT PGroup_strCode FROM XFER_tblBgSession WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

		DELETE XFER_tblBgPrices_Packages WHERE Cinema_strID = @strCinemaID AND PGroup_strCode NOT IN (SELECT DISTINCT PGroup_strCode FROM XFER_tblBgSession WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

		DELETE XFER_tblBgBookingFee WHERE Cinema_strID = @strCinemaID AND BFee_strCode NOT IN (SELECT DISTINCT BFee_strCode FROM XFER_tblBgPrices WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

	END

	-- Insert/Update into Film tables

	DECLARE @strFilmCode As VarChar(50)
	DECLARE curFilm CURSOR LOCAL FORWARD_ONLY FOR
		SELECT UPPER((@strFilmCodePrefix + Film_strCode)) As Film_strCode FROM XFER_tblBgFilm WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID ORDER BY Film_strCode

	OPEN curFilm

	WHILE 0 = 0 BEGIN

		FETCH NEXT FROM curFilm INTO @strFilmCode

		IF @@FETCH_STATUS <> 0 BREAK

		IF EXISTS (SELECT * FROM SYN_tblFilm WITH(NOLOCK) WHERE UPPER(Film_strCode) = @strFilmCode) BEGIN

			UPDATE SYN_tblFilm 
				SET Film_strTitle = X.Film_strTitle, 
					Film_strCensor = X.Film_strCensor, 
					Film_strContent = X.Film_strContent, 
					Film_strDescription = X.Film_strDescription, 
					Film_strShortName = X.Film_strShortName, 
					Film_strSignText = X.Film_strSignText, 
					Film_bytSignSequence = X.Film_bytSignSequence, 
					FilmCat_strCode = X.FilmCat_strCode,
					FilmCat_strName = X.FilmCat_strName,
					FilmCat_strShortName = X.FilmCat_strShortName, 
					Film_strChildren = X.Film_strChildren, 
					Film_intDuration = X.Film_intDuration, 
					Film_strStatus = X.Film_strStatus, 
					Film_strATMAvailable = X.Film_strATMAvailable, 
					Film_strShortCode = X.Film_strShortCode, 
					Film_intIVRCode = X.Film_intIVRCode, 
					Film_strURL1 = X.Film_strURL1, 
					Film_strURL2 = X.Film_strURL2, 
					Film_strVCode = X.Film_strVCode, 
					Film_strTitleAlt = X.Film_strTitleAlt, 
					Film_strCensorAlt = X.Film_strCensorAlt, 
					Film_strContentAlt = X.Film_strContentAlt, 
					Film_strDescriptionAlt = X.Film_strDescriptionAlt, 
					Film_strShortNameAlt = X.Film_strShortNameAlt, 
					Film_strSignTextAlt = X.Film_strSignTextAlt, 
					Film_strURL1Description = X.Film_strURL1Description, 
					Film_strURL2Description = X.Film_strURL2Description, 
					Film_strURLforGraphic = X.Film_strURLforGraphic, 
					Film_strURLforFilmName = X.Film_strURLforFilmName, 
					Film_strURLforTrailer = X.Film_strURLforTrailer, 
					Film_strMovieFormat = X.Film_strMovieFormat, 
					Film_strSoundFormat = X.Film_strSoundFormat, 
					Film_mnyGross = X.Film_mnyGross, 
					Film_mnyLocalGross = X.Film_mnyLocalGross, 
					Film_strUpcomingFlag = X.Film_strUpcomingFlag, 
					Film_strFeatureFlag = X.Film_strFeatureFlag, 
					Film_strNowShowingFlag = X.Film_strNowShowingFlag, 
					Film_dtmOpeningDate = X.Film_dtmOpeningDate, 
					Film_strDescriptionLong = X.Film_strDescriptionLong, 
					Film_strAdditionalData = X.Film_strAdditionalData,
					Film_strSalesChannels = X.Film_strSalesChannels
			FROM SYN_tblFilm S WITH(NOLOCK) INNER JOIN XFER_tblBgFilm X WITH(NOLOCK) ON (LOWER(S.Film_strCode) = LOWER(@strFilmCodePrefix + X.Film_strCode))
			WHERE X.Cinema_strID = @strCinemaID 
				AND LOWER(S.Film_strCode) = LOWER(@strFilmCode)

			DELETE SYN_tblPerson WHERE LOWER(Film_strCode) = LOWER(@strFilmCode)
			DELETE SYN_tblFilm_Attribute WHERE LOWER(Film_strCode) = LOWER(@strFilmCode)

		END ELSE BEGIN

			INSERT INTO SYN_tblFilm (Film_strCode, Film_strTitle, Film_strCensor, Film_strContent, Film_strDescription, Film_strShortName, Film_strSignText, Film_bytSignSequence, FilmCat_strCode, FilmCat_strName, FilmCat_strShortName, Film_strChildren, Film_intDuration, Film_strStatus, Film_strATMAvailable, Film_strShortCode, Film_intIVRCode, Film_strURL1, Film_strURL2, Film_strVCode, Film_strTitleAlt, Film_strCensorAlt, Film_strContentAlt, Film_strDescriptionAlt, Film_strShortNameAlt, Film_strSignTextAlt, Film_strURL1Description, Film_strURL2Description, Film_strURLforGraphic, Film_strURLforFilmName, Film_strURLforTrailer, Film_strMovieFormat, Film_strSoundFormat, Film_mnyGross, Film_mnyLocalGross, Film_strUpcomingFlag, Film_strFeatureFlag, Film_strNowShowingFlag, Film_dtmOpeningDate, Film_strDescriptionLong, Film_strAdditionalData, Film_strSalesChannels)
				(SELECT UPPER((@strFilmCodePrefix + Film_strCode)) As Film_strCode, Film_strTitle, Film_strCensor, Film_strContent, Film_strDescription, Film_strShortName, Film_strSignText, Film_bytSignSequence, FilmCat_strCode, FilmCat_strName, FilmCat_strShortName, Film_strChildren, Film_intDuration, Film_strStatus, Film_strATMAvailable, Film_strShortCode, Film_intIVRCode, Film_strURL1, Film_strURL2, Film_strVCode, Film_strTitleAlt, Film_strCensorAlt, Film_strContentAlt, Film_strDescriptionAlt, Film_strShortNameAlt, Film_strSignTextAlt, Film_strURL1Description, Film_strURL2Description, Film_strURLforGraphic, Film_strURLforFilmName, Film_strURLforTrailer, Film_strMovieFormat, Film_strSoundFormat, Film_mnyGross, Film_mnyLocalGross, Film_strUpcomingFlag, Film_strFeatureFlag, Film_strNowShowingFlag, Film_dtmOpeningDate, Film_strDescriptionLong, Film_strAdditionalData, Film_strSalesChannels FROM XFER_tblBgFilm WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID AND UPPER((@strFilmCodePrefix + Film_strCode)) = UPPER(@strFilmCode))

		END

		INSERT INTO SYN_tblPerson (Film_strCode, FPerson_strType, Person_strCode, Person_strFirstName, Person_strLastName, Person_strURLToDetails, Person_strURLToPicture, Person_strAdditionalData)
			(SELECT UPPER((@strFilmCodePrefix + Film_strCode)) As Film_strCode, FPerson_strType, Person_strCode, Person_strFirstName, Person_strLastName, Person_strURLToDetails, Person_strURLToPicture, Person_strAdditionalData FROM XFER_tblBgPerson WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID AND UPPER((@strFilmCodePrefix + Film_strCode)) = UPPER(@strFilmCode))

		INSERT INTO SYN_tblFilm_Attribute (Film_strCode, Attrib_strCode, Attrib_strClass, Attrib_strDescription, Attrib_strShortName, Attrib_strAltDescription, Attrib_strAltShortName, Attrib_strIconName, Attrib_strHOCode, Attrib_strStatus)
			(SELECT UPPER((@strFilmCodePrefix + Film_strCode)) As Film_strCode, Attrib_strCode, Attrib_strClass, Attrib_strDescription, Attrib_strShortName, Attrib_strAltDescription, Attrib_strAltShortName, Attrib_strIconName, Attrib_strHOCode, Attrib_strStatus FROM XFER_tblBgFilm_Attribute WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID AND UPPER((@strFilmCodePrefix + Film_strCode)) = UPPER(@strFilmCode))

	END

	CLOSE curFilm
	DEALLOCATE curFilm

	--END Film UPDATE / INSERT

	-- Transfer data from XFER tables to SYN tables

	INSERT INTO SYN_tblItems (Cinema_strID, Item_strID, Item_strDescription, Item_intPrice, Item_strVoiceFileName, Item_strMasterItemCode, Item_strAdditionalData, Item_intTax1, Item_intTax2, Item_intTax3, Item_intTax4, Item_strPackage, CinOperator_strCode)
		(SELECT Cinema_strID, Item_strID, Item_strDescription, Item_intPrice, Item_strVoiceFileName, Item_strMasterItemCode, Item_strAdditionalData, Item_intTax1, Item_intTax2, Item_intTax3, Item_intTax4, Item_strPackage, CinOperator_strCode FROM XFER_tblBgItems WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

	INSERT INTO SYN_tblBookingFee (Cinema_strID, BFee_strCode, License_strType, TType_strCode, BFee_curFeeMinimum, BFee_curFeeMaximum, BFee_curFee) 
		(SELECT Cinema_strID, BFee_strCode, License_strType, TType_strCode, BFee_curFeeMinimum, BFee_curFeeMaximum, BFee_curFee FROM XFER_tblBgBookingFee WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

	INSERT INTO SYN_tblPrices (Cinema_strID, PGroup_strCode, TType_strCode, AreaCat_strCode, BFee_strCode, TType_strDescription, TType_strDescriptionAlt, Price_intSequence, Price_curPrice, Price_strChildTicket, Price_strPackage, Price_strComp, Price_dtmEffectFrom, Price_dtmEffectTill, Price_strQuantity, Price_strAdditionalData, Price_strSalesChannels, Price_curTax1, Price_curTax2, Price_curTax3, Price_curTax4, TType_strHOCode)
		(SELECT Cinema_strID, PGroup_strCode, TType_strCode, AreaCat_strCode, BFee_strCode, dbo.fnFormatString(TType_strDescription, 'P'), dbo.fnFormatString(TType_strDescriptionAlt, 'P'), Price_intSequence, Price_curPrice, Price_strChildTicket, Price_strPackage, Price_strComp, Price_dtmEffectFrom, Price_dtmEffectTill, Price_strQuantity, Price_strAdditionalData, Price_strSalesChannels, Price_curTax1, Price_curTax2, Price_curTax3, Price_curTax4, TType_strHOCode FROM XFER_tblBgPrices WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

	INSERT INTO SYN_tblPrices_Packages (Cinema_strID, PPack_strCode, PGroup_strCode, TType_strCode, TType_strChildCode, Item_strItemId, PPack_curQuantity, PPack_curPriceEach, Price_curTax1, Price_curTax2, Price_curTax3, Price_curTax4)
		(SELECT Cinema_strID, PPack_strCode, PGroup_strCode, TType_strCode, TType_strChildCode, Item_strItemId, PPack_curQuantity, PPack_curPriceEach, Price_curTax1, Price_curTax2, Price_curTax3, Price_curTax4 FROM XFER_tblBgPrices_Packages WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

	INSERT INTO SYN_tblSession (Cinema_strID, Session_lngSessionId, Film_strCode, Screen_bytNum, Layout_intId, Screen_strName, Session_strStatus, Session_strType, Session_dtmRealShow, Session_dtmFinishShow, PGroup_strCode, Session_intSeatsAvail, Session_intSeatsTotal, Session_strSeatAllocation, Session_strComments, Session_dtmFilmFirstShow, Session_strHOSessionID, Event_strCode, Event_strName, Session_strAdditionalData, Session_strSalesChannel, CinOperator_strCode, Session_strCinemaPopUpDesc)
		(SELECT Cinema_strID, Session_lngSessionId, (@strFilmCodePrefix + UPPER(Film_strCode)) As Film_strCode, Screen_bytNum, Layout_intId, Screen_strName, Session_strStatus, Session_strType, Session_dtmRealShow, Session_dtmFinishShow, PGroup_strCode, Session_intSeatsAvail, Session_intSeatsTotal, Session_strSeatAllocation, Session_strComments, Session_dtmFilmFirstShow, Session_strHOSessionID, Event_strCode, Event_strName, Session_strAdditionalData, Session_strSalesChannel, CinOperator_strCode, Session_strCinemaPopUpDesc FROM XFER_tblBgSession WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

	INSERT INTO SYN_tblSession_AreaCount (Cinema_strID, Session_lngSessionId, AreaCat_strCode, Area_bytNum, SessAC_intSeatsAvail, SessAC_intSeatsTotal, SessAC_strSeatAllocation, SessAC_strAdditionalData)
		(SELECT Cinema_strID, Session_lngSessionId, AreaCat_strCode, Area_bytNum, SessAC_intSeatsAvail, SessAC_intSeatsTotal, SessAC_strSeatAllocation, SessAC_strAdditionalData FROM XFER_tblBgSession_AreaCount WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

	INSERT INTO SYN_tblSession_Attribute (Cinema_strID, Session_lngSessionId, Attrib_strCode, Attrib_strClass, Attrib_strDescription, Attrib_strShortName, Attrib_strAltDescription, Attrib_strAltShortName, Attrib_strIconName, Attrib_strHOCode, Attrib_strStatus)
		(SELECT Cinema_strID, Session_lngSessionId, Attrib_strCode, Attrib_strClass, Attrib_strDescription, Attrib_strShortName, Attrib_strAltDescription, Attrib_strAltShortName, Attrib_strIconName, Attrib_strHOCode, Attrib_strStatus FROM XFER_tblBgSession_Attribute WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)
	
	INSERT INTO SYN_tblItem_Prices (Cinema_strID, PriceH_strCode, Item_strID, Item_intPrice, Item_strDescription, Item_strMasterItemCode, Price_dtmEffectiveFrom, Price_dtmEffectiveTo, Price_intStartTime, Price_intEndTime, Price_strMonday, Price_strTuesday, Price_strWednesday, Price_strThursday, Price_strFriday, Price_strSaturday, Price_strSunday, Item_intTax1, Item_intTax2, Item_intTax3, Item_intTax4, Item_strPackage, CinOperator_strCode)
		(SELECT Cinema_strID, PriceH_strCode, Item_strID, Item_intPrice, Item_strDescription, Item_strMasterItemCode, Price_dtmEffectiveFrom, Price_dtmEffectiveTo, Price_intStartTime, Price_intEndTime, Price_strMonday, Price_strTuesday, Price_strWednesday, Price_strThursday, Price_strFriday, Price_strSaturday, Price_strSunday, Item_intTax1, Item_intTax2, Item_intTax3, Item_intTax4, Item_strPackage, CinOperator_strCode FROM XFER_tblBgItem_Prices WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)
		
	INSERT INTO SYN_tblItem_Packages (Cinema_strID, ItemPack_strKey, Item_strID, Item_strSubItemId, ItemPack_intSeq, ItemPack_intQuantity, ItemPack_intPrice, ItemPack_intTax1, ItemPack_intTax2, ItemPack_intTax3, ItemPack_intTax4)
		(SELECT Cinema_strID, ItemPack_strKey, Item_strID, Item_strSubItemId, ItemPack_intSeq, ItemPack_intQuantity, ItemPack_intPrice, ItemPack_intTax1, ItemPack_intTax2, ItemPack_intTax3, ItemPack_intTax4 FROM XFER_tblBgItem_Packages WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)

	INSERT INTO SYN_tblScreen_Area (Cinema_strID, Area_bytNum, ScreenL_intId, AreaCat_strCode, AreaCat_strCode_FallbackCategory, AdvBookRule_intID, AdvBookRule_intMinutesPrior)
		(SELECT Cinema_strID, Area_bytNum, ScreenL_intId, AreaCat_strCode, AreaCat_strCode_FallbackCategory, AdvBookRule_intID, AdvBookRule_intMinutesPrior FROM XFER_tblBgScreen_Area WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)
	
	INSERT INTO SYN_tblTicketPriceAdjustment (Cinema_strID, Session_lngSessionId, AreaCat_strCode, TType_strCode, Price_intMinDaysAdvancePurchase, TPA_intTicketsRemaining, TPA_strIsAvailable)
		(SELECT Cinema_strID, Session_lngSessionId, AreaCat_strCode, TType_strCode, Price_intMinDaysAdvancePurchase, TPA_intTicketsRemaining, TPA_strIsAvailable FROM XFER_tblBgTicketPriceAdjustment WITH(NOLOCK) WHERE Cinema_strID = @strCinemaID)
	
	UPDATE tblCinema SET Cinema_dtmLastDataRefresh = GETDATE() WHERE Cinema_strID = @strCinemaID

	-- BEGIN Updation of Misc Data !!!

	DECLARE @strValue As VarChar(500)

	SELECT @strValue = ISNULL((SELECT TOP 1 Data_strValue FROM XFER_tblBgMisc WHERE Cinema_strID = @strCinemaID AND LOWER(Data_strCode) = LOWER('TimeOut')), '0')
	UPDATE tblCinema SET Cinema_intTimeOut = CONVERT(Int, @strValue) WHERE Cinema_strID = @strCinemaID

	SELECT @strValue = ISNULL((SELECT TOP 1 Data_strValue FROM XFER_tblBgMisc WHERE Cinema_strID = @strCinemaID AND LOWER(Data_strCode) = LOWER('LicenseNo')), '')
	UPDATE tblCinema SET Cinema_strLicenseNo = @strValue WHERE Cinema_strID = @strCinemaID

	SELECT @strValue = ISNULL((SELECT TOP 1 Data_strValue FROM XFER_tblBgMisc WHERE Cinema_strID = @strCinemaID AND LOWER(Data_strCode) = LOWER('LicenseName')), '')
	UPDATE tblCinema SET Cinema_strLicenseName = @strValue WHERE Cinema_strID = @strCinemaID

	SELECT @strValue = ISNULL((SELECT TOP 1 Data_strValue FROM XFER_tblBgMisc WHERE Cinema_strID = @strCinemaID AND LOWER(Data_strCode) = LOWER('BranchCode')), '')
	UPDATE tblCinema SET Cinema_strBranchCode = @strValue WHERE Cinema_strID = @strCinemaID

	SELECT @strValue = ISNULL((SELECT TOP 1 Data_strValue FROM XFER_tblBgMisc WHERE Cinema_strID = @strCinemaID AND LOWER(Data_strCode) = LOWER('UserNumber')), '')
	UPDATE tblLicenses SET License_strUserNo = @strValue WHERE Cinema_strID = @strCinemaID AND License_strType = @strLicenseType

	SELECT @strValue = ISNULL((SELECT TOP 1 Data_strValue FROM XFER_tblBgMisc WHERE Cinema_strID = @strCinemaID AND LOWER(Data_strCode) = LOWER('WorkstationId')), '')
	UPDATE tblLicenses SET License_strWorkstationId = @strValue WHERE Cinema_strID = @strCinemaID AND License_strType = @strLicenseType

END
GO

--EXECUTE spUpdateSyncTables @strCinemaID = 'M2PP', @strLicenseType = 'MTELL'
--GO

--EXECUTE spUpdateSyncTables @strCinemaID = 'CXAW', @strLicenseType = 'MTELL'
--GO

/*********************************************************************************************

	Procedure Name: spSetSessionSold
	Last Modified:  17 Mar 2006 @ 7:00 PM
	Last Author:    Viraj Patel

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spSetSessionSold]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spSetSessionSold]
GO

CREATE PROCEDURE [dbo].[spSetSessionSold] 
	@strCinemaId As VarChar(10),
	@lngSessionId As Int,
	@strTypeCode As VarChar(4)
WITH ENCRYPTION
AS BEGIN

	DECLARE @strAreaCatCode As VarChar(10)
	DECLARE @intSeatsAvail As SmallInt

	SELECT @strAreaCatCode = P.AreaCat_strCode FROM SYN_tblSession S 
			INNER JOIN SYN_tblPrices P ON (S.Cinema_strID = P.Cinema_strID AND S.PGroup_strCode = P.PGroup_strCode) 
		WHERE S.Cinema_strID = @strCinemaId AND S.Session_lngSessionId = @lngSessionId AND P.TType_strCode = @strTypeCode

	UPDATE SYN_tblSession_AreaCount 
			SET SessAC_intSeatsAvail = 0
		WHERE Cinema_strID = @strCinemaId 
			AND Session_lngSessionId = @lngSessionId 
			AND AreaCat_strCode = @strAreaCatCode

	SELECT @intSeatsAvail = SUM(SessAC_intSeatsAvail) FROM SYN_tblSession_AreaCount
		WHERE Cinema_strID = @strCinemaId 
			AND Session_lngSessionId = @lngSessionId 

	UPDATE SYN_tblSession 
			SET Session_intSeatsAvail = @intSeatsAvail
		WHERE Cinema_strID = @strCinemaId 
			AND Session_lngSessionId = @lngSessionId 

END
GO

/*********************************************************************************************

	Procedure Name : spSaveCinema
	Last Modified  : 5 Oct 2011 @ 6:00 PM
	Last Author    : Viraj Patel

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spSaveCinema]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spSaveCinema]
GO

CREATE PROCEDURE [dbo].[spSaveCinema] 
	@strCinemaId As VarChar (10),
	@strCinemaName As VarChar(50) = NULL,
	@strScreenList As VarChar(1000) = NULL,
	@strWebServiceURL As VarChar(255) = NULL,
	@strWebServiceLogin As VarChar(50) = NULL,
	@strWebServicePWD As VarChar(50) = NULL,
	@strWebServiceDomain As VarChar(50) = NULL,
	@intWebServiceTimeOut As Int = NULL, 
	@strIsOnline As VarChar(1) = NULL,
	@intSyncSequence As SmallInt = NULL,
	@strCompanyCode As VarChar(10) = NULL,
	@strRegion As VarChar(30) = NULL,
	@strLicenseType As VarChar(10) = NULL,
	@strLicenseCode As VarChar(50) = NULL,
	@strPayType As VarChar(50) = NULL,
	@strParams As VarChar(255) = NULL, 
	@strUseHOCode As VarChar(1) = NULL
WITH ENCRYPTION
AS BEGIN

	DECLARE @intRecords As Int

	IF NOT EXISTS (SELECT 'Yes' FROM tblCinema WHERE Cinema_strID = @strCinemaId) BEGIN

		SELECT @intRecords = COUNT(*) FROM tblCinema
		SET @intRecords = ISNULL(@intRecords, 0) + 1

		INSERT INTO tblCinema 
			(Cinema_strID, 
			Cinema_strName, 
			Cinema_strScreenList,
			Cinema_strWebServiceURL, 
			Cinema_strWebServiceLogin, 
			Cinema_strWebServicePWD, 
			Cinema_strWebServiceDomain, 
			Cinema_intWebTimeOut, 
			Cinema_strIsOnline, 
			Cinema_intSyncSequence, 
			Cinema_strCompanyCode, 
			Cinema_strRegion,
			Cinema_strParams, 
			Cinema_strUseHOCode)
		VALUES 
			(@strCinemaId, 
			ISNULL(@strCinemaName, ''), 
			ISNULL(@strScreenList, ''), 
			ISNULL(@strWebServiceURL, ''), 
			ISNULL(@strWebServiceLogin, ''), 
			ISNULL(@strWebServicePWD, ''), 
			ISNULL(@strWebServiceDomain, ''), 
			ISNULL(@intWebServiceTimeOut, 45), 
			ISNULL(@strIsOnline, 'Y'), 
			ISNULL(@intSyncSequence, @intRecords), 
			ISNULL(@strCompanyCode, ''), 
			ISNULL(@strRegion, ''),
			ISNULL(@strParams, ''), 
			ISNULL(@strUseHOCode, 'N'))
	END ELSE BEGIN
		UPDATE tblCinema
			SET 	Cinema_strName = ISNULL(@strCinemaName, C.Cinema_strName), 
				Cinema_strScreenList = ISNULL(@strScreenList, C.Cinema_strScreenList), 
				Cinema_strWebServiceURL = ISNULL(@strWebServiceURL, C.Cinema_strWebServiceURL), 
				Cinema_strWebServiceLogin = ISNULL(@strWebServiceLogin, C.Cinema_strWebServiceLogin), 
				Cinema_strWebServicePWD = ISNULL(@strWebServicePWD, C.Cinema_strWebServicePWD), 
				Cinema_strWebServiceDomain = ISNULL(@strWebServiceDomain, C.Cinema_strWebServiceDomain), 
				Cinema_intWebTimeOut = ISNULL(@intWebServiceTimeOut, C.Cinema_intWebTimeOut), 
				Cinema_strIsOnline = ISNULL(@strIsOnline, C.Cinema_strIsOnline), 
				Cinema_intSyncSequence = ISNULL(@intSyncSequence, C.Cinema_intSyncSequence), 
				Cinema_strCompanyCode = ISNULL(@strCompanyCode, C.Cinema_strCompanyCode), 
				Cinema_strRegion = ISNULL(@strRegion, C.Cinema_strRegion),
				Cinema_strParams = ISNULL(@strParams, C.Cinema_strParams), 
				Cinema_strUseHOCode = ISNULL(@strUseHOCode, C.Cinema_strUseHOCode)
		FROM tblCinema C
		WHERE Cinema_strID = @strCinemaId
	END

	IF NOT @strLicenseType IS NULL BEGIN
		IF NOT EXISTS (SELECT 'Yes' FROM tblLicenses WHERE Cinema_strID = @strCinemaId AND License_strType = @strLicenseType) BEGIN
			INSERT INTO tblLicenses (Cinema_strID, License_strType, License_strCode, License_strPayType)
				VALUES (@strCinemaId, @strLicenseType, ISNULL(@strLicenseCode, ''), ISNULL(@strPayType, ''))
		END ELSE BEGIN
			UPDATE tblLicenses 
				SET License_strCode = ISNULL(@strLicenseCode, L.License_strCode),
					License_strPayType = ISNULL(@strPayType, L.License_strPayType)
			FROM tblLicenses L
			WHERE Cinema_strID = @strCinemaId AND License_strType = @strLicenseType
		END
	END

END
GO

/*********************************************************************************************

	Procedure Name : spSaveCinemaSetting
	Last Modified  : 6 Jul 2012 @ 1:00 PM
	Last Author    : Viraj Patel

	Returns        :  0 for success, any other value means failed
	                 -1 for cinema NOT found
	                 -2 means the ParamName is NULL
	                 -3 means the ParamValue is NULL

**********************************************************************************************/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[spSaveCinemaSetting]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[spSaveCinemaSetting]
GO

CREATE PROCEDURE [dbo].[spSaveCinemaSetting] 
	@strCinemaId As VarChar (10),
	@strParamName As VarChar(50),
	@strParamValue As VarChar(1000)
WITH ENCRYPTION
AS BEGIN

	IF NOT EXISTS (SELECT 1 FROM tblCinema WITH (NOLOCK) WHERE Cinema_strID = @strCinemaId) BEGIN
		RETURN -1
	END

	IF @strParamName IS NULL BEGIN
		RETURN -2
	END

	IF @strParamValue IS NULL BEGIN
		RETURN -3
	END

	SET TRANSACTION ISOLATION LEVEL SERIALIZABLE

	BEGIN TRANSACTION

		IF NOT EXISTS (SELECT 1 FROM tblCinema_Settings WITH (UPDLOCK) WHERE Cinema_strID = @strCinemaId AND LOWER(Cinema_strParamName) = LOWER(@strParamName)) BEGIN
			INSERT INTO tblCinema_Settings
				   (Cinema_strID, Cinema_strParamName, Cinema_strParamValue, Cinema_dtmParamStamp)
			VALUES (@strCinemaId, @strParamName,       @strParamValue,       GETDATE())
		END ELSE BEGIN
			UPDATE tblCinema_Settings WITH (ROWLOCK)
				SET Cinema_strParamValue = @strParamValue,
				    Cinema_dtmParamStamp = GETDATE()
			WHERE Cinema_strID = @strCinemaId 
				AND LOWER(Cinema_strParamName) = LOWER(@strParamName)
		END

	COMMIT TRANSACTION

	RETURN 0

END
GO

/* *************************************************************************************************

	Script Name   : tblBgTables Creation and Population Script for VISTACS
	Last Modified : 24 May 2010 @ 2:30 PM
	Last Author   : Viraj Patel

************************************************************************************************* */

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[tblBgTables]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) BEGIN

	CREATE TABLE [dbo].[tblBgTables] (
		[Table_strCode] [varchar] (25) NOT NULL PRIMARY KEY CLUSTERED,  
		[Table_strTitle] [varchar] (25) NOT NULL ,
		[Table_sntSequence] [tinyint] NOT NULL ,
		[Table_strTag] [varchar] (50) NOT NULL ,
		[Table_strName] [varchar] (50) NOT NULL ,
	) ON [PRIMARY]

END
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE name = 'Table_strOptional' AND id = object_id(N'[dbo].[tblBgTables]')) 
	ALTER TABLE [dbo].[tblBgTables]
		ADD Table_strOptional [varchar] (1) 
			CONSTRAINT DF_tblBgTables_Table_strOptional DEFAULT ('N') 
			NOT NULL  
GO

IF EXISTS (SELECT * FROM tblBgTables WHERE Table_strTitle = 'SYNC')
	DELETE tblBgTables WHERE Table_strTitle = 'SYNC'
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,   Table_strName,    Table_strOptional)
                VALUES  ('FILM',        'SYNC',         1,                 'spInsertFilm', 'XFER_tblBgFilm', 'N')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,   Table_strName,     Table_strOptional)
                VALUES  ('ITEM',        'SYNC',         2,                 'spInsertItem', 'XFER_tblBgItems', 'N')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,         Table_strName,          Table_strOptional)
                VALUES  ('BOOKINGFEE',  'SYNC',         3,                 'spInsertBookingFee', 'XFER_tblBgBookingFee', 'N')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,     Table_strName,      Table_strOptional)
                VALUES  ('PRICES',      'SYNC',         4,                 'spInsertPrices', 'XFER_tblBgPrices', 'N')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,            Table_strName,               Table_strOptional)
                VALUES  ('PACKAGES',    'SYNC',         5,                 'spInsertPricePackages', 'XFER_tblBgPrices_Packages', 'N')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,      Table_strName,       Table_strOptional)
                VALUES  ('SESSION',     'SYNC',         6,                 'spInsertSession', 'XFER_tblBgSession', 'N')
GO

INSERT INTO tblBgTables (Table_strCode,      Table_strTitle, Table_sntSequence, Table_strTag,          Table_strName,                 Table_strOptional)
                VALUES  ('SESSIONAREACOUNT', 'SYNC',         7,                 'spInsertSessionArea', 'XFER_tblBgSession_AreaCount', 'N')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,   Table_strName,    Table_strOptional)
                VALUES  ('MISC',        'SYNC',         8,                 'spInsertMisc', 'XFER_tblBgMisc', 'Y')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,     Table_strName,      Table_strOptional)
                VALUES  ('PERSON',      'SYNC',         9,                 'spInsertPerson', 'XFER_tblBgPerson', 'Y')
GO

INSERT INTO tblBgTables (Table_strCode,       Table_strTitle, Table_sntSequence, Table_strTag,            Table_strName,                 Table_strOptional)
                VALUES  ('SESSIONATTRIBUTES', 'SYNC',         10,                'spInsertSessionAttrib', 'XFER_tblBgSession_Attribute', 'Y')
GO

INSERT INTO tblBgTables (Table_strCode,    Table_strTitle, Table_sntSequence, Table_strTag,			Table_strName,				Table_strOptional)
                VALUES  ('FILMATTRIBUTES', 'SYNC',         11,                'spInsertFilmAttrib', 'XFER_tblBgFilm_Attribute', 'Y')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,			Table_strName,				Table_strOptional)
                VALUES  ('ITEMPRICES',  'SYNC',         12,                'spInsertItemPrices',	'XFER_tblBgItem_Prices',	'Y')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,			Table_strName,				Table_strOptional)
                VALUES  ('ITEMPACKAGES','SYNC',         13,				   'spInsertItemPackages',	'XFER_tblBgItem_Packages',	'Y')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,			Table_strName,				Table_strOptional)
                VALUES  ('SCREENAREA',  'SYNC',         14,                'spInsertScreenArea',	'XFER_tblBgScreen_Area',	'Y')
GO

INSERT INTO tblBgTables (Table_strCode, Table_strTitle, Table_sntSequence, Table_strTag,					Table_strName,						Table_strOptional)
                VALUES  ('PRICEADJUST', 'SYNC',         15,                'spInsertTicketPriceAdjustment', 'XFER_tblBgTicketPriceAdjustment',	'Y')
GO

