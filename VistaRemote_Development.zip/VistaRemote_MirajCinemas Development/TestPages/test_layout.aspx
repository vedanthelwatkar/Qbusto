<script language="vb" runat="server">

    Private colA As VistaRemote.colAreas
    Private intNoAllotedSeats As Int16                  'No of Seats Requested By the User
    Private BCBooked As System.Drawing.Color            'Booked
    Private BCHouseOrSpecial As System.Drawing.Color    'House / Special
    Private BCCurrentOrder As System.Drawing.Color      'Current Order
    Private BCAvailable As System.Drawing.Color         'Available
    Private BCOtherArea As System.Drawing.Color         'Area Other Than Current Booking
    Private strImgUrl As String                         'The url of the Image for screen
    Private intTableWidth As Int16                      'The Width of table in percentage
    Private strSeatsAlloted As String                   'The Seats Alloted by system
    Private strBooked As String                         'Text To Display as Booked Legend
    Private strAvailable As String                      'Text To Display as Available Legend
    Private strCurrentOrder As String                   'Text To Display as Current Order Legend

    Dim strSessId, strType, strTransId, strCinemaId, strSelectedSeats As String
    Dim intQty As Int16
    Dim objBook As New Bigtree.VistaRemote.clsBook

    Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim strReply As String
        Dim intRet As Int16
        Dim table1 As Object

	Response.Write("<HEAD><title>Test: SeatLayout</title></HEAD>")

        BCBooked = System.Drawing.Color.Blue
        BCHouseOrSpecial = System.Drawing.Color.Red
        BCCurrentOrder = System.Drawing.Color.Green
        BCAvailable = System.Drawing.Color.White
        BCOtherArea = System.Drawing.Color.Wheat
        intTableWidth = 90
        strBooked = "Booked"
        strAvailable = "Available"
        strCurrentOrder = "Current Order"

        strCinemaId = "0001"
        strSessId = 9425
        strType = "0002"
        intQty = 2

        ' End Initialize VistaRemote DLL

        ' Set the basic properties of the VistaRemote object - IT IS MANDITORY TO SET THESE PROPERTIES FOR DLL TO WORK.

	objBook.blnSetSettings("ConnectionString", ConfigurationSettings.AppSettings("ConnectionString"))
	objBook.blnSetSettings("LicenseType", ConfigurationSettings.AppSettings("LicenceType"))

        ' End Set basic properties

        strReply = Request.QueryString.Item("Reply")
        intNoAllotedSeats = Request.QueryString.Item("NoAllotedSeats")
        If strReply = "True" Then
            intRet = intChkSeats()
            If intRet = 0 Then
                Response.Write("Success")
                'If the user does not change the system alloted seats.
            ElseIf intRet = -1 Then
                strTransId = Request.QueryString.Item("TransactionId")
                If objBook.blnSetSeats(strCinemaId, strTransId, strSessId, strSelectedSeats) Then
                    Response.Write("SetSeats Success " & objBook.strSeatInfo)
                    Response.End()
                    'If the user changes the system alloted seats.
                End If
            Else
                Response.Write("Failed")
                'If the Transaction Fails due to More / Less No. of Seats being Selected by user.
            End If
        Else
            InitBooking()
        End If

        ' Initialize VistaRemote DLL

        If objBook.blnGetSeatLayout(strCinemaId, strTransId, strSessId) = True Then
            colA = objBook.colA
            Response.Write("TransId : " & strTransId & "<BR>")
            createChkBoxes()
	Else
            Response.Write("ERROR - blnGetSeatLayout : " & objBook.strException)
        End If

        ' Commit the Booking

        'If objBook.blnCommitBook(strcinemaid, strTransId, strSessId, False, "1234123412341234", 9, 9, "Viraj Patel", "9820816637", "testing", "pickup") Then
        '    Response.Write("Booking Id : " & objBook.intBookId & vbCrLf & "Seating : " & objBook.strSeatInfo & vbCrLf & "Total : " & objBook.curTotal & "<BR>")
        'Else
        '    Response.Write(objBook.strException)
        'End If

        ' End of Commit

    End Sub

    Private Sub InitBooking()

        ' Initialize Booking

        If objBook.blnInitBook(strcinemaid) Then
            strTransId = objBook.strTransId
            Response.Write("objInitBook is successful<BR>")
            ' Here you have to capture the property "objBook.strTransId" which is kind of a "SessionID" in ASP. 
            ' This strTransId will help you to complete this transaction in the next page
            ' Lets consider that the transaction id returned was "200000000325"
        Else
            Response.Write(objBook.strException)
            Response.End()
            ' This is if an error is generated, you can capture the error
        End If

        ' End Initialize Booking

        ' Add Seats to the Booking

        If objBook.blnAddSeats(strCinemaId, strTransId, strSessId, strType, intQty, False) Then
            ' This means that the seaats were successfully blocked for this booking.
            Response.Write("blnAddSeats is successful, got " & objBook.strSeatInfo & "<BR>")
        Else
            Response.Write(objBook.strException)
            Response.End()
            ' This is if an error is generated, you can capture the error
        End If

        ' End Add Seats

    End Sub

    Private Sub createChkBoxes()

        Dim CheckBox1 As CheckBox
        Dim table As New Table
        Dim tr() As TableRow
        Dim td(), tdRowPhyId As TableCell
        Dim seatCount As Int16
        Dim objA As VistaRemote.objArea
        Dim objR As VistaRemote.objRow
        Dim objS As VistaRemote.objSeat
        Dim intCtrArea, intCtrRow, intCtrSeats As Int16
        Dim blnShowAvailInArea As Boolean
        Dim myform As New HtmlForm
        Dim hiddenTextBox As New HtmlControls.HtmlInputHidden

        Response.Write("The Seats Alloted Are " & strSeatsAlloted)
        table.CellPadding = 0
        table.CellSpacing = 0
        table.BorderStyle = BorderStyle.Solid
        table.BorderWidth = System.Web.UI.WebControls.Unit.Pixel(1)
        table.Width = Unit.Percentage(intTableWidth)

        hiddenTextBox.Name = "HiddenText"
        hiddenTextBox.ID = "HiddenText"

        For intCtrArea = 1 To colA.Count

            objA = colA.Item(intCtrArea)
            ReDim tr(objA.colRows.Count)

            For intCtrRow = objA.colRows.Count To 1 Step -1

                objR = objA.colRows.Item(intCtrRow)
                tr(intCtrRow) = New TableRow
                table.Rows.Add(tr(intCtrRow))

                tdRowPhyId = New TableCell
                tdRowPhyId.Text = objR.strRowPhyID
                tdRowPhyId.BackColor = System.Drawing.Color.White
                tr(intCtrRow).Cells.Add(tdRowPhyId)

                ReDim td(colA.intMaxSeatId)
                blnShowAvailInArea = objA.blnHasCurrentOrder

                For intCtrSeats = colA.intMaxSeatId To colA.intMinSeatId Step -1

                    objS = objR.colSeats.GetSeatById(intCtrSeats)

                    td(intCtrSeats) = New TableCell

                    If objS.strGridSeatNum = 0 Then
                        td(intCtrSeats).Text = "&nbsp;"
                        td(intCtrSeats).BackColor = System.Drawing.Color.Black
                    Else
                        CheckBox1 = New CheckBox
                        Select Case objS.strSeatStatus
                            Case 1 ' Booked
                                td(intCtrSeats).Text = "&nbsp;"
                                td(intCtrSeats).BackColor = BCBooked
                            Case 3 ' House / Special
                                td(intCtrSeats).Text = "&nbsp;"
                                td(intCtrSeats).BackColor = BCHouseOrSpecial
                            Case 5 ' Current Order
                                td(intCtrSeats).Text = "&nbsp;"
                                td(intCtrSeats).BackColor = BCCurrentOrder
                                CheckBox1.Checked = True
                                intNoAllotedSeats = intNoAllotedSeats + 1
                                CheckBox1.ID = "SeatsChk_" & objA.strAreaCode & "|" & objA.strAreaNum & "|" & objR.intGridRowID & "|" & objS.strGridSeatNum
                                hiddenTextBox.Value = hiddenTextBox.Value & "|" & objA.strAreaCode & "|" & objA.strAreaNum & "|" & objR.intGridRowID & "|" & objS.strGridSeatNum
                                td(intCtrSeats).Controls.Add(CheckBox1)
                            Case Else ' 0 - Available
                                If blnShowAvailInArea = True Then
                                    td(intCtrSeats).Text = "&nbsp;"
                                    td(intCtrSeats).BackColor = BCAvailable
                                    CheckBox1 = New CheckBox
                                    CheckBox1.ID = "SeatsChk_" & objA.strAreaCode & "|" & objA.strAreaNum & "|" & objR.intGridRowID & "|" & objS.strGridSeatNum
                                    CheckBox1.Checked = False
                                    td(intCtrSeats).Controls.Add(CheckBox1)
                                Else
                                    td(intCtrSeats).Text = "&nbsp;"
                                    td(intCtrSeats).BackColor = BCOtherArea
                                End If
                        End Select
                    End If
                    td(intCtrSeats).BorderWidth = Unit.Pixel(1)
                    tr(intCtrRow).BorderWidth = Unit.Pixel(1)
                    tr(intCtrRow).Cells.Add(td(intCtrSeats))
                Next
                intCtrSeats = 0
            Next
        Next

        Dim td1 As New System.Web.UI.WebControls.TableCell
        Dim tr1 As New System.Web.UI.WebControls.TableRow

        myform.EnableViewState = False

        td1.Text = "<INPUT TYPE=submit VALUE=""Go"" onClick=""_ctl0.action='SeatLayout.aspx?Reply=True&NoAllotedSeats=" & intNoAllotedSeats & "&TransactionId=" & strTransId & "';"">"
        tr1.Cells.Add(td1)
        table.Rows.Add(tr1)

        myform.Controls.Add(hiddenTextBox)
        myform.Controls.Add(table)
        Me.AddParsedSubObject(myform)
	Response.Write("<BR>Done")

    End Sub

    Private Function intChkSeats() As Int16

        Dim intCount, intNoSelectedSeats As Int16
        Dim strAllotedSeats As String

        For intCount = 1 To Request.Form.Count - 1

            If Mid(Request.Form.AllKeys(intCount), 1, 9) = "SeatsChk_" Then

                intNoSelectedSeats = intNoSelectedSeats + 1
                strSelectedSeats = strSelectedSeats & "|" & Mid(Request.Form.AllKeys(intCount), 10, Len(Request.Form.AllKeys(intCount)))

            ElseIf Request.Form.AllKeys(intCount) = "HiddenText" Then

                strAllotedSeats = Request.Form.Item("HiddenText")

            End If

        Next

        If intNoSelectedSeats = intNoAllotedSeats Then
            intChkSeats = 0

            If strAllotedSeats <> strSelectedSeats Then
                intChkSeats = -1
            End If
            strSelectedSeats = "|" & intNoAllotedSeats & strSelectedSeats & "|"
        Else
            intChkSeats = 1
        End If

    End Function

</script>

