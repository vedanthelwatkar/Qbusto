<html>
  <head>
    <title>Test: Booking Process without Layout - 19 Jan 2006 @ 1:40 PM</title>
  </head>
</html>

<script language="vb" runat="server">

	Sub Page_Load(sender As System.Object, e As System.EventArgs)

		' Initialize Variables

		Dim objBook As New Bigtree.VistaRemote.clsBook
		Dim strTransId As String
		Dim strConnectionString As String = "SERVER=BIGSRV01;UID=sa;DATABASE=MovieTell;Network Library=dbmssocn;"

		Const strCinemaId As String = "BGVC"
		Const strLicenseType As String = "WWW"
		Const blnSeatLayout As Boolean = False
		Const lngSessId As Int64 = 19400
		Const strType As String = "0002"
		Const intQty As Int16 = 2
		Const blnPaid As Boolean = True
		Const curBookingFee As Single = 5.75

		' Set the basic properties of the VistaRemote object 
		' - IT IS MANDITORY TO SET THESE PROPERTIES FOR DLL TO WORK.
		' - These settings are to be set in the Page_Load of every page.

		objBook.blnSetSettings("ConnectionString", strConnectionString)
		objBook.blnSetSettings("LicenseType", strLicenseType)

		' Identify the VistaRemote Version (This can be very handy at times)

		Response.Write(objBook.strGetVersion & "<BR><BR>")

		' Initialize Booking

		If objBook.blnTestRemote(strCinemaId) Then
			Response.Write("Testing was Successful....<BR>")
			Response.Write(objBook.strException & "<BR>")
		Else
			Response.Write("<BR>intException : " & objBook.intException & "<BR>strException : " & objBook.strException & "<BR>")
			Response.Write(objBook.strSeatInfo & "<BR><BR>")
			Exit Sub
		End If

		Response.Write("---------------------------------------------<BR>")

		If objBook.blnInitBook(strCinemaId) Then
			strTransId = objBook.strTransId
			Response.Write("objInitBook is successful<BR>")

			' Here you have to capture the property "objBook.strTransId" which is kind of a "SessionID" in ASP. 
			' This strTransId will help you to complete this transaction in the next page
			' Lets consider that the transaction id returned was "200000000325"
		Else
			Response.Write("<BR>intException : " & objBook.intException & "<BR>strException : " & objBook.strException & "<BR><BR>")
			Exit Sub
			' This is if an error is generated, you can capture the error
		End If

		' Add Seats to the Booking

		If objBook.blnAddSeats(strCinemaId, strTransId, lngSessId, strType, intQty, blnSeatLayout) Then
			' This means that the seaats were successfully blocked for this booking.
			Response.Write("blnAddSeats is successful, got " & objBook.strSeatInfo & "<BR>")
		Else
			' This is if an error is generated, you can capture the error
			Response.Write("<BR>intException : " & objBook.intException & "<BR>strException : " & objBook.strException)

			If objBook.intException = 3 Then
				Response.Write(". However, you can book " & objBook.intExceptionEx & " tickets.")
			End If
			Response.Write("<BR><BR>")
			objBook.blnCancelTrans(strCinemaId, strTransId)
			Exit Sub
		End If

		' Set Booking Fees

		If objBook.blnSetBookingFee(strCinemaId, strTransId, curBookingFee, intQty) Then
			' This means that the booking fee was set successfully.
			Response.Write("blnSetBookingFee is successful<BR>")
		Else
			' This is if an error is generated, you can capture the error
			Response.Write("<BR>intException : " & objBook.intException & "<BR>strException : " & objBook.strException & "<BR><BR>")
		End If

		' Commit the Booking

		If objBook.blnCommitBook(strCinemaId, strTransId, lngSessId, blnPaid, "1234123412341234", "VISA", 9, 9, "123", "Viraj Patel", "9820816637", "testing", "pickup") Then
			Response.Write("Booking Id : " & objBook.intBookId & "<BR>Seating : " & objBook.strSeatInfo & "<BR>Tickets Total : " & objBook.curTicketsTotal & "<BR>Booking Fee : " & objBook.curBookingFee & "<BR>Total : " & objBook.curTotal & "<BR>")
		Else
			Response.Write("intException : " & objBook.intException & "<BR>strException : " & objBook.strException & "<BR>")
			objBook.blnCancelTrans(strCinemaId, strTransId)
			Exit Sub
		End If

	End Sub

</script>
