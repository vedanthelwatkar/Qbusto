<html>
  <head>
    <title>Test: VistaRemote Connectivity to Cinema Web Service</title>
  </head>
</html>

<FORM NAME="test" ID="test" RUNAT="server" METHOD="get">
	Cinema Code  : <INPUT TYPE="TEXT" VALUE="0001" NAME="txtCinemaCode"><BR>
	License Type : <INPUT TYPE="TEXT" VALUE="CALL" NAME="txtLicenseType"><BR>
	<INPUT TYPE="SUBMIT">
</FORM>

<script language="vb" runat="server">

	Sub Page_Load(sender As System.Object, e As System.EventArgs)
		If IsPostBack = True Then
			TestRemote(Request("txtCinemaCode"), Request("txtLicenseType"))
		End If
	End Sub

	Sub TestRemote(ByVal strCinemaId, ByVal strLicenseType)

		' Initialize Variables

		Dim objBook As New Bigtree.VistaRemote.clsBook
		'Dim strConnectionString As String = System.Configuration.ConfigurationSettings.AppSettings.Get("ConnectionString")
		Dim strConnectionString As String = "SERVER=BIGSRV01;UID=sa;DATABASE=MovieTell;Network Library=dbmssocn;"

		If objBook.blnSetSettings("ConnectionString", strConnectionString) = False Then
			Response.Write("Error setting 'ConnectionString' setting !!! Please check the LOG file !!!")
		End If

		objBook.blnSetSettings("LicenseType", strLicenseType)

		' Identify the VistaRemote Version (This can be very handy at times)

		Response.Write(objBook.strGetVersion & "<BR><BR>")

		' Test VistaRemote 

		If objBook.blnTestRemote(strCinemaId) Then
			Response.Write("Testing was Successful....<BR>")
			Response.Write(objBook.strException & "<BR>")
		Else
			Response.Write("intException : " & objBook.intException & "<BR>strException : " & objBook.strException & "<BR>")
			Response.Write(objBook.strSeatInfo)
		End If

		Response.Write("-------------------------------------------------------------------------<BR>")

	End Sub

</script>
