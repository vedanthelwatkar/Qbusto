<html>
  <head>
    <title>Test: Data Synchronize</title>
  </head>
</html>

<script language="vb" runat="server">

	Sub Page_Load(sender As System.Object, e As System.EventArgs)

		' Initialize VistaRemote DLL

		Dim objBook As New Bigtree.VistaRemote.clsBook

		Const strLicenseType As String = "WWW"
		Const strConnectionString As String = "SERVER=BIGSRV01;UID=sa;DATABASE=MovieTell;Network Library=dbmssocn;"

		' End Initialize VistaRemote DLL

		' Set the basic properties of the VistaRemote object - IT IS MANDITORY TO SET THESE PROPERTIES FOR DLL TO WORK.

		objBook.blnSetSettings("ConnectionString", strConnectionString)
		objBook.blnSetSettings("LicenseType", strLicenseType)

		' End Set basic properties

		' Identify the VistaRemote Version (This can be very handy at times)

		Response.Write(objBook.strGetVersion & "<BR><BR>")

		' Synchronizing Data

		Response.Write("Sync'ing Data : ")
		If objBook.blnSyncData(strLicenseType, True, "", "") Then
			Response.Write("SUCCESSFUL !!!<BR><BR>")
		Else
			Response.Write("ERROR - " & objBook.strException & "<BR><BR>")
			Exit Sub
		End If

	End Sub

</script>
